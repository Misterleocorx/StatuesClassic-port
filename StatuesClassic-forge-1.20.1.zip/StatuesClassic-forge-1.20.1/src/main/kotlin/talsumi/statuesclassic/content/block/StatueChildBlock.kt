package talsumi.statuesclassic.content.block

import net.minecraft.core.BlockPos
import net.minecraft.world.InteractionHand
import net.minecraft.world.InteractionResult
import net.minecraft.world.entity.player.Player
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.phys.BlockHitResult
import talsumi.statuesclassic.content.blockentity.StatueBE
import talsumi.statuesclassic.content.menu.StatueEquipmentMenu

class StatueChildBlock(properties: BlockBehaviour.Properties) : AbstractStatueBlock(properties) {

    override fun neighborChanged(state: BlockState, level: Level, pos: BlockPos, block: Block, fromPos: BlockPos, isMoving: Boolean)
    {
        if (level.getBlockState(pos.below()).block !is StatueParentBlock)
            replace(level, pos.below(), pos)

        super.neighborChanged(state, level, pos, block, fromPos, isMoving)
    }

    override fun use(state: BlockState, level: Level, pos: BlockPos, player: Player, hand: InteractionHand, hit: BlockHitResult): InteractionResult
    {
        val be = level.getBlockEntity(pos.below()) ?: return InteractionResult.FAIL

        if (level.isClientSide) return InteractionResult.SUCCESS

        if (be is StatueBE)
            if (!be.onRightClicked(player, hand, player.getItemInHand(hand), player.isShiftKeyDown))
                StatueEquipmentMenu.open(player, be)

        return InteractionResult.SUCCESS
    }

    override fun onRemove(state: BlockState, level: Level, pos: BlockPos, newState: BlockState, isMoving: Boolean)
    {
        if (state.block != newState.block) {
            if (level.getBlockState(pos.below()).block is StatueParentBlock) {
                replace(level, pos, pos.below())
            }
        }

        super.onRemove(state, level, pos, newState, isMoving)
    }
}
