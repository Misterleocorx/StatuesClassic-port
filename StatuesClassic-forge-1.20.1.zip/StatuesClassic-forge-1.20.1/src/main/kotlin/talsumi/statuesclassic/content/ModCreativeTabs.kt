package talsumi.statuesclassic.content

import net.minecraft.core.registries.Registries
import net.minecraft.network.chat.Component
import net.minecraft.world.item.CreativeModeTab
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraftforge.registries.DeferredRegister
import talsumi.statuesclassic.StatuesClassic

object ModCreativeTabs {

    val TABS: DeferredRegister<CreativeModeTab> = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, StatuesClassic.MODID)

    val MAIN = TABS.register(StatuesClassic.MODID) {
        CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.statuesclassic.statuesclassic"))
            .icon { ItemStack(Items.PLAYER_HEAD) }
            .displayItems { _, output ->
                output.accept(ModItems.STATUE_HAMMER.get())
                output.accept(ModItems.PALETTE.get())
            }
            .build()
    }
}
