package talsumi.statuesclassic.content

import net.minecraft.world.level.block.entity.BlockEntityType
import net.minecraftforge.registries.DeferredRegister
import net.minecraftforge.registries.ForgeRegistries
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.content.blockentity.StatueBE

object ModBlockEntities {

    val BLOCK_ENTITIES: DeferredRegister<BlockEntityType<*>> = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, StatuesClassic.MODID)

    val STATUE = BLOCK_ENTITIES.register("statue") {
        BlockEntityType.Builder.of(
            BlockEntityType.BlockEntitySupplier<StatueBE> { pos, state -> StatueBE(pos, state) },
            ModBlocks.STATUE_PARENT.get()
        ).build(null)
    }
}
