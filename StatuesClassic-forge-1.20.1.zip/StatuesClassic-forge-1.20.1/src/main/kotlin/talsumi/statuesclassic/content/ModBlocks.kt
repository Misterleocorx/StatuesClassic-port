package talsumi.statuesclassic.content

import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraft.world.level.material.MapColor
import net.minecraftforge.registries.DeferredRegister
import net.minecraftforge.registries.ForgeRegistries
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.content.block.AbstractStatueBlock
import talsumi.statuesclassic.content.block.StatueChildBlock
import talsumi.statuesclassic.content.block.StatueParentBlock

object ModBlocks {

    val BLOCKS: DeferredRegister<Block> = DeferredRegister.create(ForgeRegistries.BLOCKS, StatuesClassic.MODID)

    private fun statueProperties(): BlockBehaviour.Properties =
        BlockBehaviour.Properties.of()
            .mapColor(MapColor.STONE)
            .strength(2f)
            .noOcclusion()
            .noLootTable()
            .lightLevel { state -> AbstractStatueBlock.luminance(state) }

    val STATUE_CHILD = BLOCKS.register("statue_child") { StatueChildBlock(statueProperties()) }
    val STATUE_PARENT = BLOCKS.register("statue_parent") { StatueParentBlock(statueProperties()) }
}
