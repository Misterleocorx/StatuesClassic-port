package talsumi.statuesclassic.content.block

import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.world.InteractionHand
import net.minecraft.world.InteractionResult
import net.minecraft.world.entity.player.Player
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.EntityBlock
import net.minecraft.world.level.block.entity.BlockEntity
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.level.block.state.StateDefinition
import net.minecraft.world.level.block.state.properties.BlockStateProperties
import net.minecraft.world.phys.BlockHitResult
import talsumi.statuesclassic.content.blockentity.StatueBE
import talsumi.statuesclassic.content.menu.StatueEquipmentMenu

class StatueParentBlock(properties: BlockBehaviour.Properties) : AbstractStatueBlock(properties), EntityBlock {

    init
    {
        registerDefaultState(defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH))
    }

    override fun neighborChanged(state: BlockState, level: Level, pos: BlockPos, block: Block, fromPos: BlockPos, isMoving: Boolean)
    {
        if (level.getBlockState(pos.above()).block !is StatueChildBlock)
            replace(level, pos.above(), pos)

        super.neighborChanged(state, level, pos, block, fromPos, isMoving)
    }

    override fun use(state: BlockState, level: Level, pos: BlockPos, player: Player, hand: InteractionHand, hit: BlockHitResult): InteractionResult
    {
        val be = level.getBlockEntity(pos) ?: return InteractionResult.FAIL

        if (level.isClientSide) return InteractionResult.SUCCESS

        if (be is StatueBE)
            if (!be.onRightClicked(player, hand, player.getItemInHand(hand), player.isShiftKeyDown))
                StatueEquipmentMenu.open(player, be)

        return InteractionResult.SUCCESS
    }

    override fun onRemove(state: BlockState, level: Level, pos: BlockPos, newState: BlockState, isMoving: Boolean)
    {
        if (state.block != newState.block) {
            if (level.getBlockState(pos.above()).block is StatueChildBlock)
                replace(level, pos, pos.above())
        }

        super.onRemove(state, level, pos, newState, isMoving)
    }

    override fun createBlockStateDefinition(builder: StateDefinition.Builder<Block, BlockState>)
    {
        super.createBlockStateDefinition(builder)
        builder.add(BlockStateProperties.HORIZONTAL_FACING)
    }

    override fun newBlockEntity(pos: BlockPos, state: BlockState): BlockEntity = StatueBE(pos, state)
}
