package talsumi.statuesclassic.content.blockentity

import net.minecraft.core.BlockPos
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.nbt.CompoundTag
import net.minecraft.nbt.NbtUtils
import net.minecraft.network.protocol.Packet
import net.minecraft.network.protocol.game.ClientGamePacketListener
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket
import net.minecraft.world.InteractionHand
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.entity.BlockEntity
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.phys.AABB
import net.minecraft.world.phys.Vec3
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.content.ModBlockEntities
import talsumi.statuesclassic.content.ModItems
import talsumi.statuesclassic.core.ItemUtil
import talsumi.statuesclassic.core.StatueData
import talsumi.statuesclassic.core.StatueHelper
import talsumi.statuesclassic.core.StatuePlayerEntityFactory
import java.util.*

class StatueBE(pos: BlockPos, state: BlockState) : BlockEntity(ModBlockEntities.STATUE.get(), pos, state) {

    /**
     * 0: Head
     * 1: Chest
     * 2: Legs
     * 3: Boots
     * 4: Right hand
     * 5: Left hand
     */
    val inventory = StatueInventory { onContentsChanged() }

    var hasBeenSetup = false
    var playerUuid: UUID? = null
    var playerName: String? = null
    var data: StatueData? = null
    var block: BlockState? = null

    var hasCape = false
    var isColoured = false
    var hasName = false
    var leftHandRotate = 0f
    var rightHandRotate = 0f

    var statueId: UUID = UUID.randomUUID()

    /**
     * Note: This is an AbstractClientPlayer on client.
     * The entity is not present in the world, and *should* be GC'ed when this BlockEntity is.
     */
    var clientFakePlayer: Player? = null

    /**
     * Called when either of the statue's blocks is activated with an item.
     * Returns true if further processing is to be skipped.
     */
    fun onRightClicked(player: Player, hand: InteractionHand, item: ItemStack, sneaking: Boolean): Boolean
    {
        if (!hasBeenSetup)
            return false

        val level = level ?: return false

        val override = when (item.item) {
            Items.LEATHER -> { hasCape = !hasCape; if (hasCape) item.shrink(1) else ItemUtil.dropStack(level, player.position(), ItemStack(Items.LEATHER)); true }
            Items.PAPER -> { hasName = !hasName; if (hasName) item.shrink(1) else ItemUtil.dropStack(level, player.position(), ItemStack(Items.PAPER)); true }
            ModItems.PALETTE.get() -> { isColoured = !isColoured; if (isColoured) item.shrink(1) else ItemUtil.dropStack(level, player.position(), ItemStack(ModItems.PALETTE.get())); true }
            Items.GUNPOWDER -> { if (StatueHelper.getStatueLuminance(this) > 0) { StatueHelper.modifyStatueLuminance(this, 0); item.shrink(1) }; true }
            Items.GLOWSTONE_DUST -> { if (StatueHelper.getStatueLuminance(this) < 15) { StatueHelper.modifyStatueLuminance(this, 15); item.shrink(1) }; true }
            else -> false
        }

        if (override) {
            sendUpdatePacket()
            setChanged()
        }

        return override
    }

    /**
     * Drops everything the statue holds. Safe to call more than once.
     */
    fun statueRemoved()
    {
        val level = level ?: return
        val dropPos = Vec3(blockPos.x + 0.5, blockPos.y + 1.0, blockPos.z + 0.5)

        for (i in 0 until inventory.slots)
            ItemUtil.dropStack(level, dropPos, inventory.getStackInSlot(i).copy(), 10)
        inventory.clearSilently()

        if (hasCape)
            ItemUtil.dropStack(level, dropPos, ItemStack(Items.LEATHER), 10)
        if (hasName)
            ItemUtil.dropStack(level, dropPos, ItemStack(Items.PAPER), 10)
        if (isColoured)
            ItemUtil.dropStack(level, dropPos, ItemStack(ModItems.PALETTE.get()), 10)

        hasCape = false
        hasName = false
        isColoured = false
    }

    fun setup(block: BlockState, name: String, uuid: UUID, data: StatueData)
    {
        this.playerUuid = uuid
        this.data = data
        this.playerName = name
        this.block = block
        hasBeenSetup = true
        setChanged()
        StatuesClassic.LOGGER.debug("Created statue at $blockPos, for player $uuid, made of $block")
    }

    override fun setLevel(level: Level)
    {
        super.setLevel(level)

        if (level.isClientSide)
            clientFakePlayer = StatuePlayerEntityFactory.getStatuePlayer(this, level, blockPos)
    }

    /**
     * Sends this BlockEntity's data to every client tracking it. Does nothing on the client.
     */
    fun sendUpdatePacket()
    {
        val level = level ?: return
        if (!level.isClientSide)
            level.sendBlockUpdated(blockPos, blockState, blockState, 3)
    }

    private fun onContentsChanged()
    {
        if (hasBeenSetup)
            sendUpdatePacket()

        setChanged()
    }

    //The statue is two blocks tall and its limbs can swing outside of its own block, so use a larger box to stop it being culled early.
    override fun getRenderBoundingBox(): AABB =
        AABB(blockPos.x - 1.0, blockPos.y - 1.0, blockPos.z - 1.0, blockPos.x + 2.0, blockPos.y + 3.0, blockPos.z + 2.0)

    //Syncing with the client. Both the initial chunk load and later updates use the same data as saving.
    override fun getUpdateTag(): CompoundTag = saveWithoutMetadata()

    override fun getUpdatePacket(): Packet<ClientGamePacketListener>? = ClientboundBlockEntityDataPacket.create(this)

    override fun load(nbt: CompoundTag)
    {
        super.load(nbt)

        inventory.deserializeNBT(nbt.getCompound("inventory"))
        hasBeenSetup = nbt.getBoolean("has_setup")
        if (hasBeenSetup) {
            data = StatueData.load(nbt.getCompound("statue_data"))
            playerUuid = nbt.getUUID("player_uuid")
            playerName = nbt.getString("player_name")
            block = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), nbt.getCompound("block")).takeIf { !it.isAir }
            leftHandRotate = nbt.getFloat("left_hand_rotate")
            rightHandRotate = nbt.getFloat("right_hand_rotate")
            hasCape = nbt.getBoolean("has_cape")
            isColoured = nbt.getBoolean("is_coloured")
            hasName = nbt.getBoolean("shows_name")

            //If we are made of an invalid block, mark the statue as un-setup.
            if (block == null) {
                hasBeenSetup = false
                setChanged()
            }
        }
    }

    override fun saveAdditional(nbt: CompoundTag)
    {
        super.saveAdditional(nbt)

        nbt.put("inventory", inventory.serializeNBT())
        nbt.putBoolean("has_setup", hasBeenSetup)
        if (hasBeenSetup) {
            nbt.put("statue_data", data!!.save())
            nbt.putUUID("player_uuid", playerUuid!!)
            nbt.putString("player_name", playerName!!)
            nbt.put("block", NbtUtils.writeBlockState(block!!))
            nbt.putFloat("left_hand_rotate", leftHandRotate)
            nbt.putFloat("right_hand_rotate", rightHandRotate)
            nbt.putBoolean("has_cape", hasCape)
            nbt.putBoolean("is_coloured", isColoured)
            nbt.putBoolean("shows_name", hasName)
        }
    }
}
