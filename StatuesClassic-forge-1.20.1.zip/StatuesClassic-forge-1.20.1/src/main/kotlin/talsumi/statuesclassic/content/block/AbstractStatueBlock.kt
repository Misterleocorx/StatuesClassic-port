package talsumi.statuesclassic.content.block

import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.world.level.BlockGetter
import net.minecraft.world.level.Level
import net.minecraft.world.level.LevelAccessor
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.RenderShape
import net.minecraft.world.level.block.SimpleWaterloggedBlock
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.level.block.state.StateDefinition
import net.minecraft.world.level.block.state.properties.BlockStateProperties
import net.minecraft.world.level.block.state.properties.IntegerProperty
import net.minecraft.world.level.material.FluidState
import net.minecraft.world.level.material.Fluids
import talsumi.statuesclassic.core.StatueHelper

abstract class AbstractStatueBlock(properties: BlockBehaviour.Properties) : Block(properties), SimpleWaterloggedBlock {

    companion object {
        val lightLevel: IntegerProperty = IntegerProperty.create("light_level", 0, 15)

        fun luminance(state: BlockState): Int = state.getValue(lightLevel)
    }

    init
    {
        registerDefaultState(defaultBlockState().setValue(lightLevel, 0).setValue(BlockStateProperties.WATERLOGGED, false))
    }

    fun replace(level: Level, pos1: BlockPos, pos2: BlockPos)
    {
        val replacement = StatueHelper.removeStatue(level, pos1)
        level.removeBlock(pos2, false)
        level.setBlockAndUpdate(pos2, replacement)
        level.setBlockAndUpdate(pos1, replacement)
    }

    override fun getFluidState(state: BlockState): FluidState =
        if (state.getValue(BlockStateProperties.WATERLOGGED)) Fluids.WATER.getSource(false) else super.getFluidState(state)

    override fun updateShape(state: BlockState, direction: Direction, neighborState: BlockState, level: LevelAccessor, pos: BlockPos, neighborPos: BlockPos): BlockState
    {
        if (state.getValue(BlockStateProperties.WATERLOGGED))
            level.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level))
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos)
    }

    override fun propagatesSkylightDown(state: BlockState, level: BlockGetter, pos: BlockPos): Boolean = true

    override fun getRenderShape(state: BlockState): RenderShape = RenderShape.INVISIBLE

    override fun getShadeBrightness(state: BlockState, level: BlockGetter, pos: BlockPos): Float = 1f

    override fun createBlockStateDefinition(builder: StateDefinition.Builder<Block, BlockState>)
    {
        builder.add(lightLevel)
        builder.add(BlockStateProperties.WATERLOGGED)
    }
}
