package talsumi.statuesclassic.content

import net.minecraft.world.item.Item
import net.minecraftforge.registries.DeferredRegister
import net.minecraftforge.registries.ForgeRegistries
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.content.item.StatueHammerItem

object ModItems {

    val ITEMS: DeferredRegister<Item> = DeferredRegister.create(ForgeRegistries.ITEMS, StatuesClassic.MODID)

    val STATUE_HAMMER = ITEMS.register("statue_hammer") { StatueHammerItem(Item.Properties().stacksTo(1)) }
    val PALETTE = ITEMS.register("palette") { Item(Item.Properties()) }
}
