package talsumi.statuesclassic.content.menu

import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.SimpleMenuProvider
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.entity.player.Player
import net.minecraft.world.inventory.AbstractContainerMenu
import net.minecraft.world.inventory.MenuType
import net.minecraft.world.item.ItemStack
import net.minecraft.world.level.Level
import net.minecraftforge.network.NetworkHooks
import talsumi.statuesclassic.content.ModMenus
import talsumi.statuesclassic.core.StatueData
import talsumi.statuesclassic.core.StatueHelper
import java.util.*

class StatueCreationMenu(type: MenuType<*>?, syncId: Int, val hitFace: Direction?, val playerFacing: Direction?, val parentPos: BlockPos, val level: Level?) : AbstractContainerMenu(type, syncId) {

    //Client Constructor
    constructor(syncId: Int, inv: Inventory, buf: FriendlyByteBuf) : this(syncId, null, null, buf.readBlockPos(), null)

    //Common Constructor
    constructor(syncId: Int, hitFace: Direction?, playerFacing: Direction?, parentPos: BlockPos, level: Level?) : this(ModMenus.STATUE_CREATION.get(), syncId, hitFace, playerFacing, parentPos, level)

    /**
     * Called on the server when the client presses the "Sculpt" button.
     */
    fun form(player: ServerPlayer, name: String, uuid: UUID, data: StatueData)
    {
        if (level != null) {
            val direction = if (hitFace == Direction.UP || hitFace == Direction.DOWN) playerFacing!!.opposite else hitFace!!.opposite
            StatueHelper.tryCreateStatue(parentPos, level, name, uuid, data, direction)
        }
        player.closeContainer()
    }

    override fun quickMoveStack(player: Player, index: Int): ItemStack = ItemStack.EMPTY

    override fun stillValid(player: Player): Boolean = true

    companion object {

        /**
         * Opens the creation screen for [player]. Server only.
         */
        fun open(player: Player, hitFace: Direction, pos: BlockPos, level: Level)
        {
            if (player !is ServerPlayer) return

            val provider = SimpleMenuProvider({ syncId, _, p ->
                //Note: the first two directions are intentionally passed in this order, as in the original mod (the statue faces the player who made it).
                StatueCreationMenu(syncId, p.direction, hitFace, pos, level)
            }, Component.empty())

            NetworkHooks.openScreen(player, provider) { buf -> buf.writeBlockPos(pos) }
        }
    }
}
