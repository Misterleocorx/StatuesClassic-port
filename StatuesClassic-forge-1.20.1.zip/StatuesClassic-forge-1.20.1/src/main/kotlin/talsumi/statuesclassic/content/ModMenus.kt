package talsumi.statuesclassic.content

import net.minecraft.world.inventory.MenuType
import net.minecraftforge.common.extensions.IForgeMenuType
import net.minecraftforge.registries.DeferredRegister
import net.minecraftforge.registries.ForgeRegistries
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.content.menu.StatueCreationMenu
import talsumi.statuesclassic.content.menu.StatueEquipmentMenu

object ModMenus {

    val MENUS: DeferredRegister<MenuType<*>> = DeferredRegister.create(ForgeRegistries.MENU_TYPES, StatuesClassic.MODID)

    val STATUE_EQUIPMENT = MENUS.register("statue_equipment_screen") {
        IForgeMenuType.create { id, inv, buf -> StatueEquipmentMenu(id, inv, buf) }
    }

    val STATUE_CREATION = MENUS.register("statue_creation_screen") {
        IForgeMenuType.create { id, inv, buf -> StatueCreationMenu(id, inv, buf) }
    }
}
