package talsumi.statuesclassic.content.menu

import net.minecraft.core.BlockPos
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.SimpleMenuProvider
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.entity.player.Player
import net.minecraft.world.inventory.AbstractContainerMenu
import net.minecraft.world.inventory.MenuType
import net.minecraft.world.inventory.Slot
import net.minecraft.world.item.ItemStack
import net.minecraftforge.items.IItemHandler
import net.minecraftforge.items.SlotItemHandler
import net.minecraftforge.network.NetworkHooks
import talsumi.statuesclassic.client.ClientAccess
import talsumi.statuesclassic.content.ModMenus
import talsumi.statuesclassic.content.blockentity.StatueBE
import talsumi.statuesclassic.content.blockentity.StatueInventory
import talsumi.statuesclassic.core.StatueHelper

class StatueEquipmentMenu(type: MenuType<*>?, syncId: Int, val inv: IItemHandler, val statue: StatueBE?) : AbstractContainerMenu(type, syncId) {

    //Client Constructor. The client side uses a detached inventory that the server keeps in sync.
    constructor(syncId: Int, inv: Inventory, buf: FriendlyByteBuf) : this(syncId, inv, StatueInventory(), ClientAccess.getStatue(buf.readBlockPos()))

    //Common Constructor
    constructor(syncId: Int, pInv: Inventory, inv: IItemHandler, statue: StatueBE?) : this(ModMenus.STATUE_EQUIPMENT.get(), syncId, inv, statue)
    {
        setup(pInv, inv)
    }

    private fun setup(pInv: Inventory, inv: IItemHandler)
    {
        //Player inventory. These take up slots 0-35.
        for (row in 0 until 3)
            for (col in 0 until 9)
                addSlot(Slot(pInv, col + row * 9 + 9, 8 + col * 18, 96 + row * 18))
        for (col in 0 until 9)
            addSlot(Slot(pInv, col, 8 + col * 18, 96 + 58))

        //Statue slots. Armour (head to boots) in a column, then the two hands.
        for (row in 0 until 4)
            addSlot(SlotItemHandler(inv, row, 80, 8 + row * 18))
        addSlot(SlotItemHandler(inv, 4, 61, 34))
        addSlot(SlotItemHandler(inv, 5, 99, 34))
    }

    fun updateHands(left: Float, right: Float)
    {
        if (statue != null)
            StatueHelper.updateStatueHands(statue.blockPos, statue.level ?: return, left, right)
    }

    override fun stillValid(player: Player): Boolean
    {
        val statue = statue ?: return false
        if (statue.isRemoved) return false

        val pos = statue.blockPos
        return player.distanceToSqr(pos.x + 0.5, pos.y + 0.5, pos.z + 0.5) <= 64.0
    }

    override fun quickMoveStack(player: Player, index: Int): ItemStack
    {
        val slot = slots.getOrNull(index) ?: return ItemStack.EMPTY
        if (!slot.hasItem()) return ItemStack.EMPTY

        val stack = slot.item
        val original = stack.copy()

        if (index >= PLAYER_SLOTS) {
            //Statue -> player
            if (!moveItemStackTo(stack, 0, PLAYER_SLOTS, true))
                return ItemStack.EMPTY
        }
        else {
            //Player -> statue
            if (!moveItemStackTo(stack, PLAYER_SLOTS, PLAYER_SLOTS + STATUE_SLOTS, false))
                return ItemStack.EMPTY
        }

        if (stack.isEmpty) slot.setByPlayer(ItemStack.EMPTY) else slot.setChanged()

        if (stack.count == original.count)
            return ItemStack.EMPTY

        slot.onTake(player, stack)
        return original
    }

    companion object {
        private const val PLAYER_SLOTS = 36
        private const val STATUE_SLOTS = 6

        /**
         * Opens the equipment screen for [player]. Server only.
         */
        fun open(player: Player, statue: StatueBE)
        {
            if (player !is ServerPlayer) return

            val provider = SimpleMenuProvider({ syncId, inv, _ ->
                StatueEquipmentMenu(syncId, inv, statue.inventory, statue)
            }, Component.empty())

            val pos: BlockPos = statue.blockPos
            NetworkHooks.openScreen(player, provider) { buf -> buf.writeBlockPos(pos) }
        }
    }
}
