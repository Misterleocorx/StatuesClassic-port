package talsumi.statuesclassic.content.item

import net.minecraft.ChatFormatting
import net.minecraft.network.chat.Component
import net.minecraft.world.InteractionResult
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.TooltipFlag
import net.minecraft.world.item.context.UseOnContext
import net.minecraft.world.level.Level
import talsumi.statuesclassic.content.menu.StatueCreationMenu
import talsumi.statuesclassic.core.StatueHelper

class StatueHammerItem(properties: Properties) : Item(properties) {

    override fun appendHoverText(stack: ItemStack, level: Level?, tooltip: MutableList<Component>, flag: TooltipFlag)
    {
        tooltip.add(Component.translatable("tooltip.statuesclassic.statue_hammer").withStyle(ChatFormatting.GRAY))
    }

    override fun useOn(ctx: UseOnContext): InteractionResult
    {
        val level = ctx.level
        if (level.isClientSide) return InteractionResult.FAIL
        val pos = ctx.clickedPos
        val state = level.getBlockState(pos)
        val player = ctx.player ?: return InteractionResult.FAIL

        if (!StatueHelper.isBlockValidForStatue(level, pos))
            return InteractionResult.FAIL

        val down = pos.below()
        val up = pos.above()

        //Check up for second block
        if (level.getBlockState(up) == state && StatueHelper.isBlockValidForStatue(level, up))
            StatueCreationMenu.open(player, ctx.clickedFace, pos, level)
        //Check down for second block
        else if (level.getBlockState(down) == state && StatueHelper.isBlockValidForStatue(level, down))
            StatueCreationMenu.open(player, ctx.clickedFace, down, level)

        return InteractionResult.SUCCESS
    }
}
