package talsumi.statuesclassic.content.blockentity

import net.minecraft.world.entity.EquipmentSlot
import net.minecraft.world.entity.Mob
import net.minecraft.world.item.BlockItem
import net.minecraft.world.item.ItemStack
import net.minecraftforge.items.ItemStackHandler

/**
 * The statue's six slots.
 *
 * 0: Head, 1: Chest, 2: Legs, 3: Boots, 4: Right hand, 5: Left hand
 *
 * Used by both the server-side [StatueBE] and the (detached) client-side menu, so both ends enforce the same slot rules.
 */
class StatueInventory(private val listener: () -> Unit = {}) : ItemStackHandler(6) {

    override fun isItemValid(slot: Int, stack: ItemStack): Boolean = when (slot) {
        0 -> stack.item is BlockItem || Mob.getEquipmentSlotForItem(stack) == EquipmentSlot.HEAD
        1 -> Mob.getEquipmentSlotForItem(stack) == EquipmentSlot.CHEST
        2 -> Mob.getEquipmentSlotForItem(stack) == EquipmentSlot.LEGS
        3 -> Mob.getEquipmentSlotForItem(stack) == EquipmentSlot.FEET
        else -> true
    }

    override fun onContentsChanged(slot: Int)
    {
        listener()
    }

    /**
     * Empties every slot without notifying the listener.
     */
    fun clearSilently()
    {
        for (i in 0 until slots)
            stacks[i] = ItemStack.EMPTY
    }
}
