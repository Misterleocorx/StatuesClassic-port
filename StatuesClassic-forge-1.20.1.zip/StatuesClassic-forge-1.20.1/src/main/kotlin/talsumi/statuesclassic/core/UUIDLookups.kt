package talsumi.statuesclassic.core

import com.mojang.authlib.Agent
import com.mojang.authlib.GameProfile
import com.mojang.authlib.ProfileLookupCallback
import net.minecraft.server.MinecraftServer
import net.minecraft.server.level.ServerPlayer
import talsumi.statuesclassic.StatuesClassic
import java.util.*
import java.util.concurrent.Executors

object UUIDLookups {

    private val executor = Executors.newCachedThreadPool()
    private val cache = HashMap<String, GameProfile?>()
    private val metadata = HashMap<UUID, Metadata>()
    private val maxFrequencyMillis = 1000L

    /**
     * Returns the cached profile for [username], if one has been looked up already. Must be called from the server thread.
     */
    fun rawGet(username: String): GameProfile?
    {
        return cache[normalise(username)]
    }

    private fun normalise(username: String): String = username.lowercase().take(16)

    /**
     * An immediate profile lookup. [whenFound] and [whenFailed] will be called on the server thread.
     */
    fun lookupProfileFromServer(server: MinecraftServer, username: String, whenFound: (GameProfile) -> Unit, whenFailed: (() -> Unit) = {})
    {
        internalLookup(server, username, whenFound, whenFailed)
    }

    /**
     * A profile lookup with limits on frequency. [whenFound] and [whenFailed] will be called on the server thread.
     */
    fun lookupProfileFromClient(player: ServerPlayer, server: MinecraftServer, username: String, whenFound: (GameProfile) -> Unit, whenFailed: (() -> Unit) = {})
    {
        val time = System.currentTimeMillis()
        val meta = metadata[player.uuid] ?: run {
            val meta = Metadata(time, false)
            metadata[player.uuid] = meta
            meta
        }

        //If the player hasn't made any lookups recently, immediately return a lookup.
        if (time >= meta.timeout) {
            internalLookup(server, username, whenFound, whenFailed)
            meta.timeout = time + maxFrequencyMillis
        }
        else {
            StatuesClassic.LOGGER.warn("Player ${player.name.string} (UUID ${player.uuid})'s frequency of requested UUID lookups has passed the allowed amount!")
        }
    }

    private fun internalLookup(server: MinecraftServer, rawUsername: String, whenFound: (GameProfile) -> Unit, whenFailed: () -> Unit)
    {
        val username = normalise(rawUsername)
        val cached = cache[username]
        if (cached != null)
            return server.execute { whenFound.invoke(cached) }
        else if (cache.containsKey(username))
            return server.execute(whenFailed)

        executor.execute {
            //The cache is only touched from the server thread, so results are always applied inside server.execute.
            server.profileRepository.findProfilesByNames(arrayOf(username), Agent.MINECRAFT, object : ProfileLookupCallback {
                override fun onProfileLookupSucceeded(profile: GameProfile)
                {
                    server.execute {
                        cache[username] = profile
                        whenFound.invoke(profile)
                    }
                }

                override fun onProfileLookupFailed(profile: GameProfile, exception: Exception)
                {
                    server.execute {
                        cache[username] = null
                        whenFailed.invoke()
                    }
                }
            })
        }
    }

    class Metadata(var timeout: Long, var hasPending: Boolean)
}
