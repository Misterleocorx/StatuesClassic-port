package talsumi.statuesclassic.core

import com.mojang.authlib.GameProfile
import net.minecraft.client.multiplayer.ClientLevel
import net.minecraft.core.BlockPos
import net.minecraft.world.entity.player.Player
import net.minecraft.world.level.Level
import talsumi.statuesclassic.client.content.entity.StatuePlayerEntity
import talsumi.statuesclassic.content.blockentity.StatueBE

/**
 * Only ever called on the client (see [StatueBE.setLevel]).
 */
object StatuePlayerEntityFactory {

    fun getStatuePlayer(statue: StatueBE, level: Level, pos: BlockPos): Player
    {
        val ent = StatuePlayerEntity(statue, level as ClientLevel, GameProfile(null, "statuesclassic_fakeplayer"))
        ent.setPos(pos.x + 0.5, pos.y + 0.0, pos.z + 0.5)
        return ent
    }
}
