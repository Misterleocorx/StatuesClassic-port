package talsumi.statuesclassic.core

import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.util.Mth
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.level.block.state.properties.BlockStateProperties
import talsumi.statuesclassic.content.ModBlocks
import talsumi.statuesclassic.content.block.AbstractStatueBlock
import talsumi.statuesclassic.content.blockentity.StatueBE
import java.util.*

object StatueHelper {

    fun isBlockValidForStatue(level: Level, pos: BlockPos): Boolean
    {
        val state = level.getBlockState(pos)
        if (state.hasBlockEntity() || level.getBlockEntity(pos) != null || state.isAir || !state.isCollisionShapeFullBlock(level, pos) || state.getDestroySpeed(level, pos) < 0)
            return false

        return true
    }

    fun canCreateStatueHere(level: Level, pos: BlockPos): Boolean
    {
        val state = level.getBlockState(pos)
        val stateUp = level.getBlockState(pos.above())

        return isBlockValidForStatue(level, pos) && isBlockValidForStatue(level, pos.above()) && state == stateUp
    }

    fun tryCreateStatue(bottomPos: BlockPos, level: Level, name: String, uuid: UUID, data: StatueData, facing: Direction)
    {
        if (canCreateStatueHere(level, bottomPos)) {
            val state = level.getBlockState(bottomPos)
            val block = level.getBlockState(bottomPos)

            //Sanity check for facing
            if (facing == Direction.UP || facing == Direction.DOWN) return

            val light = state.lightEmission.coerceIn(0, 15)

            level.setBlockAndUpdate(bottomPos, ModBlocks.STATUE_PARENT.get().defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, facing).setValue(AbstractStatueBlock.lightLevel, light))
            level.setBlockAndUpdate(bottomPos.above(), ModBlocks.STATUE_CHILD.get().defaultBlockState().setValue(AbstractStatueBlock.lightLevel, light))
            val be = level.getBlockEntity(bottomPos)

            if (be is StatueBE) {
                be.setup(block, name, uuid, data)
                level.server?.execute { be.sendUpdatePacket() }
            }
        }
    }

    fun modifyStatueLuminance(be: StatueBE, luminance: Int)
    {
        val level = be.level ?: return
        val childPos = be.blockPos.above()
        val block = level.getBlockState(be.blockPos)
        val childBlock = level.getBlockState(childPos)

        if (block.block !is AbstractStatueBlock || childBlock.block !is AbstractStatueBlock) return

        level.setBlockAndUpdate(be.blockPos, block.setValue(AbstractStatueBlock.lightLevel, luminance))
        level.setBlockAndUpdate(childPos, childBlock.setValue(AbstractStatueBlock.lightLevel, luminance))
        be.setChanged()
    }

    fun removeStatue(level: Level, pos: BlockPos): BlockState
    {
        val be = (level.getBlockEntity(pos) ?: level.getBlockEntity(pos.below())) as? StatueBE ?: return Blocks.STONE.defaultBlockState()
        return removeStatue(be)
    }

    fun removeStatue(be: StatueBE): BlockState
    {
        be.statueRemoved()
        return be.block ?: Blocks.STONE.defaultBlockState()
    }

    fun getStatueLuminance(be: StatueBE): Int = be.blockState.getValue(AbstractStatueBlock.lightLevel)

    fun updateStatueHands(pos: BlockPos, level: Level, left: Float, right: Float)
    {
        val be = level.getBlockEntity(pos)

        if (be is StatueBE) {
            //Joystick rotation is swapped. It's weird.
            be.leftHandRotate = right
            be.rightHandRotate = left
            be.setChanged()
            be.sendUpdatePacket()
        }
    }

    fun applyJoystickAnglesToStatueData(data: StatueData,
                                        joystick1Y: Float,
                                        joystick1X: Float,
                                        joystick2Y: Float,
                                        joystick2X: Float,
                                        joystick3Y: Float,
                                        joystick3X: Float,
                                        joystick4Y: Float,
                                        joystick4X: Float,
                                        joystick5Y: Float,
                                        joystick5X: Float,
                                        joystick6Y: Float,
                                        joystick6X: Float)
    {
        data.leftArmRaise = (joystick1Y * 180f) * Mth.DEG_TO_RAD
        data.leftArmRotate = -joystick1X
        data.rightArmRaise = (joystick2Y * 180f) * Mth.DEG_TO_RAD
        data.rightArmRotate = -joystick2X
        data.leftLegRaise = (joystick3Y * 100f) * Mth.DEG_TO_RAD
        data.leftLegRotate = -joystick3X
        data.rightLegRaise = (joystick4Y * 100f) * Mth.DEG_TO_RAD
        data.rightLegRotate = -joystick4X
        data.headRaise = (joystick5Y * 75f) * Mth.DEG_TO_RAD
        data.headRotate = (-joystick5X * 90f) * Mth.DEG_TO_RAD
        data.masterRaise = joystick6Y
        data.masterRotate = -joystick6X

        //How far the lowest foot has been lifted, so the statue can be lowered to stay on the ground.
        val rightLegHeight = 0.5f + data.rightLegRaise * 0.75f
        val leftLegHeight = 0.5f + data.leftLegRaise * 0.75f

        data.heightOffset = -(rightLegHeight.coerceAtLeast(leftLegHeight) + 0.05f).coerceAtMost(0f)
    }

    /**
     * Turns joystick position into rotation in degrees.
     */
    fun encodeHandRotation(joystick: Float): Float = (joystick * 90f) * Mth.DEG_TO_RAD

    /**
     * Turns rotation into joystick position
     */
    fun decodeHandRotation(rotation: Float): Float = (rotation / 90) * Mth.RAD_TO_DEG
}
