package talsumi.statuesclassic.core

import net.minecraft.world.entity.item.ItemEntity
import net.minecraft.world.item.ItemStack
import net.minecraft.world.level.Level
import net.minecraft.world.phys.Vec3

object ItemUtil {

    /**
     * Drops [stack] into the world at [pos]. Does nothing on the client or for empty stacks.
     */
    fun dropStack(level: Level, pos: Vec3, stack: ItemStack, pickupDelay: Int = 0)
    {
        if (level.isClientSide || stack.isEmpty) return

        val entity = ItemEntity(level, pos.x, pos.y, pos.z, stack)
        entity.setPickUpDelay(pickupDelay)
        level.addFreshEntity(entity)
    }
}
