package talsumi.statuesclassic.core

import net.minecraft.nbt.CompoundTag
import net.minecraft.network.FriendlyByteBuf

class StatueData(var leftArmRaise: Float,
                 var leftArmRotate: Float,
                 var rightArmRaise: Float,
                 var rightArmRotate: Float,
                 var leftLegRaise: Float,
                 var leftLegRotate: Float,
                 var rightLegRaise: Float,
                 var rightLegRotate: Float,
                 var headRaise: Float,
                 var headRotate: Float,
                 var masterRaise: Float,
                 var masterRotate: Float,
                 var heightOffset: Float) {

    companion object {
        /**
         * Reads a float sent by a client. NaN / infinity are replaced with 0 so a modified client can't push garbage into the world.
         */
        private fun readFinite(buf: FriendlyByteBuf): Float = buf.readFloat().let { if (it.isFinite()) it else 0f }

        fun fromPacket(buf: FriendlyByteBuf): StatueData
        {
            return StatueData(
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf),
                readFinite(buf)
            )
        }

        fun load(nbt: CompoundTag): StatueData
        {
            return StatueData(
                leftArmRaise = nbt.getFloat("leftArmRaise"),
                leftArmRotate = nbt.getFloat("leftArmRotate"),
                rightArmRaise = nbt.getFloat("rightArmRaise"),
                rightArmRotate = nbt.getFloat("rightArmRotate"),
                leftLegRaise = nbt.getFloat("leftLegRaise"),
                leftLegRotate = nbt.getFloat("leftLegRotate"),
                rightLegRaise = nbt.getFloat("rightLegRaise"),
                rightLegRotate = nbt.getFloat("rightLegRotate"),
                headRaise = nbt.getFloat("headRaise"),
                headRotate = nbt.getFloat("headRotate"),
                masterRaise = nbt.getFloat("masterRaise"),
                masterRotate = nbt.getFloat("masterRotate"),
                heightOffset = nbt.getFloat("heightOffset"))
        }
    }

    fun writePacket(buf: FriendlyByteBuf)
    {
        buf.writeFloat(leftArmRaise)
        buf.writeFloat(leftArmRotate)
        buf.writeFloat(rightArmRaise)
        buf.writeFloat(rightArmRotate)
        buf.writeFloat(leftLegRaise)
        buf.writeFloat(leftLegRotate)
        buf.writeFloat(rightLegRaise)
        buf.writeFloat(rightLegRotate)
        buf.writeFloat(headRaise)
        buf.writeFloat(headRotate)
        buf.writeFloat(masterRaise)
        buf.writeFloat(masterRotate)
        buf.writeFloat(heightOffset)
    }

    fun save(): CompoundTag
    {
        val nbt = CompoundTag()
        nbt.putFloat("leftArmRaise", leftArmRaise)
        nbt.putFloat("leftArmRotate", leftArmRotate)
        nbt.putFloat("rightArmRaise", rightArmRaise)
        nbt.putFloat("rightArmRotate", rightArmRotate)
        nbt.putFloat("leftLegRaise", leftLegRaise)
        nbt.putFloat("leftLegRotate", leftLegRotate)
        nbt.putFloat("rightLegRaise", rightLegRaise)
        nbt.putFloat("rightLegRotate", rightLegRotate)
        nbt.putFloat("headRaise", headRaise)
        nbt.putFloat("headRotate", headRotate)
        nbt.putFloat("masterRaise", masterRaise)
        nbt.putFloat("masterRotate", masterRotate)
        nbt.putFloat("heightOffset", heightOffset)
        return nbt
    }
}
