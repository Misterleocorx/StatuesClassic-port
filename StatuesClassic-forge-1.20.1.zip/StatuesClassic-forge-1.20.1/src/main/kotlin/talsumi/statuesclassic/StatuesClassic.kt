package talsumi.statuesclassic

import net.minecraftforge.fml.common.Mod
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import talsumi.statuesclassic.client.StatuesClassicClient
import talsumi.statuesclassic.content.ModBlockEntities
import talsumi.statuesclassic.content.ModBlocks
import talsumi.statuesclassic.content.ModCreativeTabs
import talsumi.statuesclassic.content.ModItems
import talsumi.statuesclassic.content.ModMenus
import talsumi.statuesclassic.networking.ModNetwork
import thedarkcolour.kotlinforforge.forge.MOD_BUS
import thedarkcolour.kotlinforforge.forge.runForDist

@Mod(StatuesClassic.MODID)
object StatuesClassic {

    const val MODID = "statuesclassic"

    val LOGGER: Logger = LogManager.getLogger()

    init {
        LOGGER.info("Statues Classic initializing...")

        ModBlocks.BLOCKS.register(MOD_BUS)
        ModItems.ITEMS.register(MOD_BUS)
        ModBlockEntities.BLOCK_ENTITIES.register(MOD_BUS)
        ModMenus.MENUS.register(MOD_BUS)
        ModCreativeTabs.TABS.register(MOD_BUS)

        MOD_BUS.addListener<FMLCommonSetupEvent> { event ->
            event.enqueueWork { ModNetwork.register() }
        }

        //Client-only code lives in a separate class so it is never loaded on a dedicated server.
        runForDist(
            clientTarget = { StatuesClassicClient.init() },
            serverTarget = { }
        )
    }
}
