package talsumi.statuesclassic.networking

import net.minecraft.resources.ResourceLocation
import net.minecraft.server.level.ServerPlayer
import net.minecraftforge.api.distmarker.Dist
import net.minecraftforge.fml.DistExecutor
import net.minecraftforge.network.NetworkDirection
import net.minecraftforge.network.NetworkEvent
import net.minecraftforge.network.NetworkRegistry
import net.minecraftforge.network.PacketDistributor
import net.minecraftforge.network.simple.SimpleChannel
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.client.ClientPacketHandlers
import java.util.*
import java.util.function.Supplier

object ModNetwork {

    private const val PROTOCOL = "1"

    val CHANNEL: SimpleChannel = NetworkRegistry.newSimpleChannel(
        ResourceLocation(StatuesClassic.MODID, "main"),
        { PROTOCOL },
        { it == PROTOCOL },
        { it == PROTOCOL }
    )

    fun register()
    {
        var id = 0

        //Client -> Server
        CHANNEL.registerMessage(id++, LookupUuidPacket::class.java,
            { msg, buf -> msg.encode(buf) },
            { buf -> LookupUuidPacket.decode(buf) },
            { msg, ctx -> handleOnServer(ctx) { player -> ServerPacketHandlers.receiveLookupUuid(player, msg) } },
            Optional.of(NetworkDirection.PLAY_TO_SERVER))

        CHANNEL.registerMessage(id++, FormStatuePacket::class.java,
            { msg, buf -> msg.encode(buf) },
            { buf -> FormStatuePacket.decode(buf) },
            { msg, ctx -> handleOnServer(ctx) { player -> ServerPacketHandlers.receiveFormStatue(player, msg) } },
            Optional.of(NetworkDirection.PLAY_TO_SERVER))

        CHANNEL.registerMessage(id++, UpdateStatueHandsPacket::class.java,
            { msg, buf -> msg.encode(buf) },
            { buf -> UpdateStatueHandsPacket.decode(buf) },
            { msg, ctx -> handleOnServer(ctx) { player -> ServerPacketHandlers.receiveUpdateStatueHands(player, msg) } },
            Optional.of(NetworkDirection.PLAY_TO_SERVER))

        //Server -> Client
        CHANNEL.registerMessage(id++, StatueProfilePacket::class.java,
            { msg, buf -> msg.encode(buf) },
            { buf -> StatueProfilePacket.decode(buf) },
            { msg, ctx -> handleOnClient(ctx) { ClientPacketHandlers.receiveStatueProfile(msg) } },
            Optional.of(NetworkDirection.PLAY_TO_CLIENT))

        CHANNEL.registerMessage(id++, StatueGuiHandsPacket::class.java,
            { msg, buf -> msg.encode(buf) },
            { buf -> StatueGuiHandsPacket.decode(buf) },
            { msg, ctx -> handleOnClient(ctx) { ClientPacketHandlers.receiveStatueHands(msg) } },
            Optional.of(NetworkDirection.PLAY_TO_CLIENT))
    }

    private fun handleOnServer(ctx: Supplier<NetworkEvent.Context>, action: (ServerPlayer) -> Unit)
    {
        val context = ctx.get()
        context.enqueueWork {
            val player = context.sender
            if (player != null)
                action(player)
        }
        context.packetHandled = true
    }

    private fun handleOnClient(ctx: Supplier<NetworkEvent.Context>, action: () -> Unit)
    {
        val context = ctx.get()
        //Client classes must only be touched on the client, so go through DistExecutor.
        context.enqueueWork {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT) { Runnable { action() } }
        }
        context.packetHandled = true
    }

    fun sendToServer(packet: Any)
    {
        CHANNEL.sendToServer(packet)
    }

    fun sendToClient(packet: Any, player: ServerPlayer)
    {
        CHANNEL.send(PacketDistributor.PLAYER.with { player }, packet)
    }
}
