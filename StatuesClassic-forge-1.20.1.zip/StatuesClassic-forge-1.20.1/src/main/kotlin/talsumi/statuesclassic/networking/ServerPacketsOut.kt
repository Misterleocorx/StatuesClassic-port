package talsumi.statuesclassic.networking

import com.mojang.authlib.GameProfile
import net.minecraft.server.level.ServerPlayer

object ServerPacketsOut {

    fun sendStatueProfilePacket(queriedName: String, profile: GameProfile?, player: ServerPlayer)
    {
        ModNetwork.sendToClient(StatueProfilePacket(queriedName, profile), player)
    }

    fun sendStatueHandsPacket(left: Float, right: Float, player: ServerPlayer)
    {
        ModNetwork.sendToClient(StatueGuiHandsPacket(left, right), player)
    }
}
