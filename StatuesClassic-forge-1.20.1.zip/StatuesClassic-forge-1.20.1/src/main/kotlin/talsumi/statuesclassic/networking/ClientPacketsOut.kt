package talsumi.statuesclassic.networking

import talsumi.statuesclassic.core.StatueData
import java.util.*

object ClientPacketsOut {

    fun sendFormStatuePacket(name: String, uuid: UUID, data: StatueData)
    {
        ModNetwork.sendToServer(FormStatuePacket(name, uuid, data))
    }

    fun sendUpdateStatueHandsPacket(left: Float, right: Float)
    {
        ModNetwork.sendToServer(UpdateStatueHandsPacket(left, right))
    }

    fun sendLookupUuidPacket(username: String)
    {
        ModNetwork.sendToServer(LookupUuidPacket(username))
    }
}
