package talsumi.statuesclassic.networking

import net.minecraft.server.level.ServerPlayer
import talsumi.statuesclassic.content.menu.StatueCreationMenu
import talsumi.statuesclassic.content.menu.StatueEquipmentMenu
import talsumi.statuesclassic.core.UUIDLookups

/**
 * Handlers for packets sent by clients. All of these are called on the server thread.
 */
object ServerPacketHandlers {

    private fun clampJoystick(value: Float): Float = if (value.isFinite()) value.coerceIn(-1f, 1f) else 0f

    fun receiveFormStatue(player: ServerPlayer, packet: FormStatuePacket)
    {
        //Sanity check to ensure username matches uuid
        if ((UUIDLookups.rawGet(packet.name)?.id ?: packet.uuid) == packet.uuid) {
            val menu = player.containerMenu
            if (menu is StatueCreationMenu)
                menu.form(player, packet.name, packet.uuid, packet.data)
        }
    }

    fun receiveUpdateStatueHands(player: ServerPlayer, packet: UpdateStatueHandsPacket)
    {
        val left = clampJoystick(packet.left)
        val right = clampJoystick(packet.right)

        val menu = player.containerMenu
        if (menu is StatueEquipmentMenu) {

            //Update statue hands
            menu.updateHands(left, right)

            //Update joystick positions for every other player that has this statue's screen open
            val server = player.server ?: return
            for (other in server.playerList.players) {
                if (other == player) continue

                val otherMenu = other.containerMenu
                if (otherMenu is StatueEquipmentMenu && menu.statue != null && otherMenu.statue === menu.statue)
                    ServerPacketsOut.sendStatueHandsPacket(left, right, other)
            }
        }
    }

    fun receiveLookupUuid(player: ServerPlayer, packet: LookupUuidPacket)
    {
        val server = player.server ?: return
        val username = packet.username

        if (player.containerMenu is StatueCreationMenu) {
            UUIDLookups.lookupProfileFromClient(player, server, username,
                whenFound = { ServerPacketsOut.sendStatueProfilePacket(username, it, player) },
                whenFailed = { ServerPacketsOut.sendStatueProfilePacket(username, null, player) })
        }
    }
}
