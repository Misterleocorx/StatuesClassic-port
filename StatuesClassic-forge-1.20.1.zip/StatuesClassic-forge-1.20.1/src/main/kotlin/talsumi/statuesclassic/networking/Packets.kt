package talsumi.statuesclassic.networking

import com.mojang.authlib.GameProfile
import net.minecraft.network.FriendlyByteBuf
import talsumi.statuesclassic.core.StatueData
import java.util.*

/** Client -> Server: ask the server to look up a player's UUID. */
class LookupUuidPacket(val username: String) {
    fun encode(buf: FriendlyByteBuf) { buf.writeUtf(username, 64) }

    companion object {
        fun decode(buf: FriendlyByteBuf) = LookupUuidPacket(buf.readUtf(64))
    }
}

/** Client -> Server: create the statue. */
class FormStatuePacket(val name: String, val uuid: UUID, val data: StatueData) {
    fun encode(buf: FriendlyByteBuf)
    {
        buf.writeUtf(name, 64)
        buf.writeUUID(uuid)
        data.writePacket(buf)
    }

    companion object {
        fun decode(buf: FriendlyByteBuf) = FormStatuePacket(buf.readUtf(64), buf.readUUID(), StatueData.fromPacket(buf))
    }
}

/** Client -> Server: the hand joysticks of an open equipment screen were moved. */
class UpdateStatueHandsPacket(val left: Float, val right: Float) {
    fun encode(buf: FriendlyByteBuf)
    {
        buf.writeFloat(left)
        buf.writeFloat(right)
    }

    companion object {
        fun decode(buf: FriendlyByteBuf) = UpdateStatueHandsPacket(buf.readFloat(), buf.readFloat())
    }
}

/** Server -> Client: result of a UUID lookup. [profile] is null if the lookup failed. */
class StatueProfilePacket(val queriedName: String, val profile: GameProfile?) {
    fun encode(buf: FriendlyByteBuf)
    {
        buf.writeUtf(queriedName, 64)
        buf.writeBoolean(profile != null)
        if (profile != null) {
            buf.writeUtf(profile.name, 64)
            buf.writeUUID(profile.id)
        }
    }

    companion object {
        fun decode(buf: FriendlyByteBuf): StatueProfilePacket
        {
            val queriedName = buf.readUtf(64)
            val valid = buf.readBoolean()
            val username = if (valid) buf.readUtf(64) else null
            val uuid = if (valid) buf.readUUID() else null
            return StatueProfilePacket(queriedName, if (valid) GameProfile(uuid, username) else null)
        }
    }
}

/** Server -> Client: another player moved the hand joysticks of the statue this player has open. */
class StatueGuiHandsPacket(val left: Float, val right: Float) {
    fun encode(buf: FriendlyByteBuf)
    {
        buf.writeFloat(left)
        buf.writeFloat(right)
    }

    companion object {
        fun decode(buf: FriendlyByteBuf) = StatueGuiHandsPacket(buf.readFloat(), buf.readFloat())
    }
}
