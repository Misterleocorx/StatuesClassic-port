package talsumi.statuesclassic.client.content.entity

import com.mojang.authlib.GameProfile
import net.minecraft.client.multiplayer.ClientLevel
import net.minecraft.client.player.AbstractClientPlayer
import net.minecraft.client.resources.DefaultPlayerSkin
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.entity.EquipmentSlot
import net.minecraft.world.entity.player.PlayerModelPart
import net.minecraft.world.item.ItemStack
import talsumi.statuesclassic.client.core.SkinHandler
import talsumi.statuesclassic.content.blockentity.StatueBE

/**
 * A fake player entity that delegates to a [StatueBE] for some operations. Used by the statue renderer for some operations that require an actual player.
 * This entity does not exist in the world!
 */
class StatuePlayerEntity(val statue: StatueBE, level: ClientLevel, profile: GameProfile) : AbstractClientPlayer(level, profile)
{
    override fun tick()
    {

    }

    override fun isSpectator(): Boolean = false

    override fun isCreative(): Boolean = false

    override fun getItemBySlot(slot: EquipmentSlot): ItemStack
    {
        return when (slot) {
            EquipmentSlot.MAINHAND -> statue.inventory.getStackInSlot(4)
            EquipmentSlot.OFFHAND -> statue.inventory.getStackInSlot(5)
            EquipmentSlot.FEET -> statue.inventory.getStackInSlot(3)
            EquipmentSlot.LEGS -> statue.inventory.getStackInSlot(2)
            EquipmentSlot.CHEST -> statue.inventory.getStackInSlot(1)
            EquipmentSlot.HEAD -> statue.inventory.getStackInSlot(0)
        }
    }

    override fun getUseItem(): ItemStack = statue.inventory.getStackInSlot(4)

    override fun getMainHandItem(): ItemStack = statue.inventory.getStackInSlot(4)

    override fun getOffhandItem(): ItemStack = statue.inventory.getStackInSlot(5)

    override fun isSkinLoaded(): Boolean = true

    override fun getSkinTextureLocation(): ResourceLocation =
        statue.playerUuid?.let { SkinHandler.getCachedSkin(it).getSkinOrDefault() } ?: DefaultPlayerSkin.getDefaultSkin()

    override fun isCapeLoaded(): Boolean = statue.hasCape

    override fun getCloakTextureLocation(): ResourceLocation? = statue.playerUuid?.let { SkinHandler.getCachedSkin(it).cape }

    override fun isElytraLoaded(): Boolean = isCapeLoaded()

    override fun getElytraTextureLocation(): ResourceLocation? = statue.playerUuid?.let { SkinHandler.getCachedSkin(it).elytra }

    override fun isModelPartShown(part: PlayerModelPart): Boolean = true
}
