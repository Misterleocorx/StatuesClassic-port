package talsumi.statuesclassic.client.content.screen

import net.minecraft.network.chat.Component
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.entity.player.Inventory
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.client.content.widgets.JoystickWidget
import talsumi.statuesclassic.content.menu.StatueEquipmentMenu
import talsumi.statuesclassic.networking.ClientPacketsOut

class StatueEquipmentScreen(menu: StatueEquipmentMenu, inventory: Inventory, title: Component) :
    EnhancedScreen<StatueEquipmentMenu>(menu, inventory, title, ResourceLocation(StatuesClassic.MODID, "textures/gui/statue_equipment.png")) {

    private val leftJoystick: JoystickWidget
    private val rightJoystick: JoystickWidget

    var setup = false

    init
    {
        imageHeight = 179
        leftJoystick = JoystickWidget(7, 67, 51, 14, 14, 176, 0, this,
            Component.translatable("gui.statuesclassic.joystick.equipment_right_hand"), true, callback = ::joystickChange)
        rightJoystick = JoystickWidget(117, 67, 51, 14, 14, 176, 0, this,
            Component.translatable("gui.statuesclassic.joystick.equipment_left_hand"), callback = ::joystickChange)

        addWidgets(leftJoystick, rightJoystick)

        leftJoystick.setPosition(menu.statue?.rightHandRotate ?: 0f, 0f)
        rightJoystick.setPosition(menu.statue?.leftHandRotate ?: 0f, 0f)

        setup = true
    }

    fun joysticksUpdatedFromServer(left: Float, right: Float)
    {
        leftJoystick.setPosition(left.coerceIn(-1f, 1f), 0f)
        rightJoystick.setPosition(right.coerceIn(-1f, 1f), 0f)
    }

    private fun joystickChange()
    {
        if (!setup) return //Ignore changes until [init] has finished.
        val statue = menu.statue ?: return

        //Update rotation on client only. When joysticks are released, an update packet will be sent to the server. (See mouseReleased)
        statue.rightHandRotate = leftJoystick.getXPosition()
        statue.leftHandRotate = rightJoystick.getXPosition()
    }

    override fun mouseReleased(mouseX: Double, mouseY: Double, button: Int): Boolean
    {
        //Send rotation update packet when joysticks are released
        ClientPacketsOut.sendUpdateStatueHandsPacket(
            leftJoystick.getXPosition(),
            rightJoystick.getXPosition())

        return super.mouseReleased(mouseX, mouseY, button)
    }
}
