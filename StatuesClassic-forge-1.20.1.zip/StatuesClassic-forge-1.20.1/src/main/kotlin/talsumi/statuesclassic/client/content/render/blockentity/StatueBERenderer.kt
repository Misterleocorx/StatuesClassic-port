package talsumi.statuesclassic.client.content.render.blockentity

import com.mojang.blaze3d.vertex.PoseStack
import com.mojang.blaze3d.vertex.VertexConsumer
import com.mojang.math.Axis
import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.MultiBufferSource
import net.minecraft.client.renderer.RenderType
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer
import net.minecraft.client.renderer.entity.EntityRendererProvider
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.state.BlockState
import talsumi.statuesclassic.client.content.model.StatueModel
import talsumi.statuesclassic.client.content.render.entity.StatuePlayerRenderer
import talsumi.statuesclassic.client.core.SkinHandler
import talsumi.statuesclassic.content.blockentity.StatueBE
import talsumi.statuesclassic.core.StatueData
import java.awt.Color
import java.util.*

class StatueBERenderer : BlockEntityRenderer<StatueBE> {

    /**
     * Everything that needs the game's model set to be loaded. Created on first use and thrown away on resource reload.
     */
    private class Shared {
        val model = StatueModel(false)
        val slimModel = StatueModel(true)
        val statueRenderer: StatuePlayerRenderer
        val slimStatueRenderer: StatuePlayerRenderer

        init
        {
            val mc = Minecraft.getInstance()
            val ctx = EntityRendererProvider.Context(mc.entityRenderDispatcher, mc.itemRenderer, mc.blockRenderer, mc.entityRenderDispatcher.itemInHandRenderer, mc.resourceManager, mc.entityModels, mc.font)
            statueRenderer = StatuePlayerRenderer(model, ctx, false)
            slimStatueRenderer = StatuePlayerRenderer(slimModel, ctx, true)
        }
    }

    companion object {
        private var shared: Shared? = null

        private fun shared(): Shared = shared ?: Shared().also { shared = it }

        fun reset()
        {
            shared = null
        }
    }

    private fun internalRender(statue: StatueBE?, data: StatueData, model: StatueModel, color: Color, renderer: StatuePlayerRenderer, poseStack: PoseStack, vertex: VertexConsumer, buffer: MultiBufferSource, tickDelta: Float, overlay: Int, light: Int)
    {
        poseStack.pushPose()

        //Flip so we aren't upside down
        poseStack.mulPose(Axis.XP.rotationDegrees(180f))

        //Apply rotations from data. This will carry through into a PlayerRenderer render call
        model.applyStatueData(data)

        //Our fake player is a bit hacky and may not work with all mods, so don't crash if it doesn't!
        try {
            if (statue != null) {
                //If statue BlockEntity is present, render via a PlayerRenderer. This allows armor, held items, etc.
                renderer.render(statue, data, color, tickDelta, poseStack, vertex, buffer, light, overlay)
            }
            else {
                //If statue BlockEntity isn't present, render directly from a model. Used for the statue creation GUI.
                //Apply height offset
                poseStack.translate(0.0, data.heightOffset.toDouble(), 0.0)

                //Apply master rotation
                poseStack.translate(0.0, 1.0, 0.0)
                poseStack.mulPose(Axis.YP.rotation(data.masterRotate))
                poseStack.mulPose(Axis.XP.rotation(data.masterRaise))
                poseStack.translate(0.0, -1.0, 0.0)

                model.renderToBuffer(poseStack, vertex, light, overlay, color.red / 255f, color.green / 255f, color.blue / 255f, color.alpha / 255f)
            }
        } catch (e: Exception) {

        }

        poseStack.popPose()
    }

    /**
     * Renders a statue using [data] for rotations. [statue] may be null, in which case features (Armour, held items, etc.) cannot be rendered
     */
    fun render(statue: StatueBE?, data: StatueData, block: BlockState, uuid: UUID?, slim: Boolean, texture: ResourceLocation, tickDelta: Float, poseStack: PoseStack, buffer: MultiBufferSource, light: Int, overlay: Int)
    {
        poseStack.pushPose()

        val shared = shared()
        val model = if (slim) shared.slimModel else shared.model
        val renderer = if (slim) shared.slimStatueRenderer else shared.statueRenderer
        val colorized = statue?.isColoured ?: false
        val skin = if (!colorized) SkinHandler.getTexturedSkin(uuid, block) else texture
        val color = Minecraft.getInstance().blockColors.getColor(block, null, null, 0).let { if (it > -1) Color(it) else Color.WHITE }

        if (skin != null) {
            val vertex = buffer.getBuffer(RenderType.entityTranslucent(skin))

            //Render statue
            internalRender(statue, data, model, color, renderer, poseStack, vertex, buffer, tickDelta, overlay, light)
        }

        poseStack.popPose()
    }

    override fun render(statue: StatueBE, tickDelta: Float, poseStack: PoseStack, buffer: MultiBufferSource, light: Int, overlay: Int)
    {
        if (!statue.hasBeenSetup)
            return

        val uuid = statue.playerUuid ?: return
        val data = statue.data ?: return
        val cache = SkinHandler.getCachedSkin(uuid)
        val skin = cache.skin ?: return

        poseStack.pushPose()
        poseStack.translate(0.5, 1.5, 0.5)

        render(statue, data, statue.block ?: Blocks.STONE.defaultBlockState(), uuid, cache.slim ?: false, skin, tickDelta, poseStack, buffer, light, overlay)
        poseStack.popPose()
    }
}
