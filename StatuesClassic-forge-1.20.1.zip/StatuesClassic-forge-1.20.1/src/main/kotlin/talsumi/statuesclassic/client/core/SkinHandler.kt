package talsumi.statuesclassic.client.core

import com.mojang.authlib.GameProfile
import com.mojang.authlib.minecraft.MinecraftProfileTexture
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type
import com.mojang.blaze3d.platform.NativeImage
import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.texture.DynamicTexture
import net.minecraft.client.resources.DefaultPlayerSkin
import net.minecraft.resources.ResourceLocation
import net.minecraft.server.packs.resources.ResourceManager
import net.minecraft.server.packs.resources.ResourceManagerReloadListener
import net.minecraft.Util
import net.minecraft.world.level.block.state.BlockState
import org.lwjgl.BufferUtils
import org.lwjgl.opengl.GL11
import org.lwjgl.opengl.GL12
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.client.content.render.blockentity.StatueBERenderer
import java.awt.Color
import java.io.InputStream
import java.util.*
import javax.imageio.ImageIO

object SkinHandler {

    private val executor = Util.backgroundExecutor()
    private val cache = HashMap<UUID, SkinData>()
    private val texturedCache = HashMap<Pair<UUID, BlockState>, AsyncHolder>()
    private val baseUUID = UUID.randomUUID()

    fun reset()
    {
        texturedCache.clear()
        cache.clear()
    }

    /**
     * Creates and returns a skin for [uuid], textured to look like [block]. This will return null until the skin has been created.
     */
    fun getTexturedSkin(uuid: UUID?, block: BlockState): ResourceLocation?
    {
        val key = Pair(uuid ?: baseUUID, block)
        val existing = texturedCache[key]
        if (existing != null)
            return existing.tex

        val base = (if (uuid != null) getCachedSkin(uuid).skin else DefaultPlayerSkin.getDefaultSkin()) ?: return null
        val holder = AsyncHolder(null)
        texturedCache[key] = holder
        makeTexturedSkin(base, uuid ?: baseUUID, block, holder)
        return holder.tex
    }

    private fun makeTexturedSkin(baseSkin: ResourceLocation, uuid: UUID, block: BlockState, holder: AsyncHolder)
    {
        val mc = Minecraft.getInstance()
        val textures = mc.textureManager

        //Get block texture
        var width = 0
        var height = 0
        val blockImage: IntArray
        try {
            blockImage = streamBlockTexture(block).use { ImageIO.read(it) }.let {
                width = it.width
                height = it.height
                it.getRGB(0, 0, it.width, it.height, null, 0, it.width)
            }
        } catch (e: Exception) {
            //Couldn't read the block's texture, so fall back to the untextured skin.
            StatuesClassic.LOGGER.warn("Couldn't read texture of $block for a statue, using the plain skin instead.", e)
            holder.tex = baseSkin
            return
        }
        val blockSize = height.coerceAtMost(width)
        val sampleResolution = 16.coerceAtMost(blockSize)

        //Read in skin texture
        textures.getTexture(baseSkin).bind()
        val pixelsBuffer = BufferUtils.createIntBuffer(64 * 64)
        GL11.glGetTexImage(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, GL12.GL_UNSIGNED_INT_8_8_8_8_REV, pixelsBuffer)
        val skinPixels = IntArray(64 * 64)
        pixelsBuffer.get(skinPixels)

        executor.execute {
            val newImage = NativeImage(64, 64, true)

            val skinArray = FloatArray(3)
            val blockArray = FloatArray(3)

            //Calculate the new colour of each pixel
            for (rgba in skinPixels.withIndex()) {
                val x = (rgba.index % 64)
                val y = (rgba.index / 64)
                val blockX = (x % sampleResolution) * (blockSize / sampleResolution)
                val blockY = (y % sampleResolution) * (blockSize / sampleResolution)
                val blockIndex = (blockY * width) + blockX

                newImage.setPixelRGBA(x, y, mixColors(rgba.value, blockImage[blockIndex], skinArray, blockArray))
            }

            //Textures must be created on the render thread.
            mc.execute {
                holder.tex = textures.register("statuesclassic_${uuid}_${UUID.randomUUID()}".lowercase(), DynamicTexture(newImage))
            }
        }
    }

    /**
     * Mixes two skin and block pixels.
     * [skinArray] and [blockArray] are used to store intermediate values in. They can be omitted.
     */
    private fun mixColors(skin: Int, block: Int, skinArray: FloatArray? = null, blockArray: FloatArray? = null): Int
    {
        val skinHSV = Color.RGBtoHSB(skin and 0x00FF0000 shr 16, skin and 0x0000FF00 shr 8, skin and 0x00000000FF, skinArray)
        val blockHSV = Color.RGBtoHSB(block and 0x000000FF, block and 0x0000FF00 shr 8, block and 0x00FF0000 shr 16, blockArray)
        var sV = (blockHSV[2] * 0.2f + skinHSV[2] * 0.8f).coerceIn(0f, 1f)
        val bV = blockHSV[2]
        if (sV > bV)
            sV -= (sV - bV) / 2f

        val out = Color.HSBtoRGB(blockHSV[0], blockHSV[1], sV)
        return (out and 0x00FFFFFF) or (skin and 0xFF000000.toInt())
    }

    private fun streamBlockTexture(block: BlockState): InputStream
    {
        val mc = Minecraft.getInstance()
        val name = mc.blockRenderer.blockModelShaper.getParticleIcon(block).contents().name()
        return mc.resourceManager.getResourceOrThrow(ResourceLocation(name.namespace, "textures/${name.path}.png")).open()
    }

    /**
     * Call to get a [SkinData] object. Its values will be null until they have been loaded by the game.
     */
    fun getCachedSkin(uuid: UUID): SkinData
    {
        val existing = cache[uuid]
        if (existing != null)
            return existing

        val data = SkinData(null, null, null, null)
        cache[uuid] = data

        //One request fetches every texture type.
        Minecraft.getInstance().skinManager.registerSkins(GameProfile(uuid, null), { type, id, texture ->
            when (type) {
                Type.SKIN -> {
                    data.slim = texture.getMetadata("model") == "slim"
                    data.skin = id
                }
                Type.CAPE -> data.cape = id
                Type.ELYTRA -> data.elytra = id
                else -> {}
            }
        }, true)

        return data
    }

    object ReloadListener : ResourceManagerReloadListener {
        override fun onResourceManagerReload(manager: ResourceManager)
        {
            reset()
            StatueBERenderer.reset()
        }
    }

    class SkinData(@Volatile var skin: ResourceLocation?, @Volatile var cape: ResourceLocation?, @Volatile var elytra: ResourceLocation?, @Volatile var slim: Boolean?, private var complete: Boolean = false) {

        fun isComplete(): Boolean
        {
            return if (complete) true else {
                complete = skin != null && cape != null && elytra != null && slim != null
                complete
            }
        }

        /**
         * Returns the held skin, or if it hasn't been loaded yet, the default one.
         */
        fun getSkinOrDefault(): ResourceLocation = skin ?: DefaultPlayerSkin.getDefaultSkin()

        override fun toString(): String = "SkinData(skin=$skin, cape=$cape, elytra=$elytra, slim=$slim)"
    }

    class AsyncHolder(@Volatile var tex: ResourceLocation?)
}
