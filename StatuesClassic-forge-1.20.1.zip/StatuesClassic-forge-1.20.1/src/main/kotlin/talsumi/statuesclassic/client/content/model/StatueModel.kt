package talsumi.statuesclassic.client.content.model

import net.minecraft.client.model.PlayerModel
import net.minecraft.client.model.geom.ModelPart
import net.minecraft.client.model.geom.builders.CubeDeformation
import net.minecraft.client.model.geom.builders.LayerDefinition
import net.minecraft.client.player.AbstractClientPlayer
import talsumi.statuesclassic.core.StatueData

class StatueModel(val slim: Boolean) : PlayerModel<AbstractClientPlayer>(bake(slim), slim) {

    companion object {
        private fun bake(slim: Boolean): ModelPart =
            LayerDefinition.create(PlayerModel.createMesh(CubeDeformation.NONE, slim), 64, 64).bakeRoot()
    }

    init
    {
        young = false
    }

    fun applyStatueData(data: StatueData)
    {
        //Head
        head.setRotation(data.headRaise, data.headRotate, 0f)
        hat.setRotation(data.headRaise, data.headRotate, 0f)
        //Left arm
        leftArm.setRotation(data.leftArmRaise, data.leftArmRotate, 0f)
        leftSleeve.setRotation(data.leftArmRaise, data.leftArmRotate, 0f)
        //Right arm
        rightArm.setRotation(data.rightArmRaise, data.rightArmRotate, 0f)
        rightSleeve.setRotation(data.rightArmRaise, data.rightArmRotate, 0f)
        //Left leg
        leftLeg.setRotation(data.leftLegRaise, data.leftLegRotate, 0f)
        leftPants.setRotation(data.leftLegRaise, data.leftLegRotate, 0f)
        //Right leg
        rightLeg.setRotation(data.rightLegRaise, data.rightLegRotate, 0f)
        rightPants.setRotation(data.rightLegRaise, data.rightLegRotate, 0f)
    }
}
