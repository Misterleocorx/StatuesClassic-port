package talsumi.statuesclassic.client.content.widgets

import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphics
import net.minecraft.network.chat.Component

open class ButtonWidget(x: Int, y: Int, width: Int, height: Int, val u: Int, val v: Int, val function: (() -> Unit)? = null, val text: (() -> Component)? = null, val isActive: (() -> Boolean)? = null) : BaseWidget(x, y, width, height) {

    override fun doRender(graphics: GuiGraphics, x: Int, y: Int, mouseX: Int, mouseY: Int, delta: Float)
    {
        val x = this.x + x
        val y = this.y + y

        var v = v

        val active = isActive?.invoke() != false

        if (!active)
            v += height

        if (isHovered(x, y, mouseX, mouseY) || !active)
            graphics.blit(parentScreen.guiTexture, x, y, u, v, width, height)

        text?.invoke()?.let { graphics.drawCenteredString(Minecraft.getInstance().font, it, x + width / 2, y + (height - 8) / 2, 16777215) }
    }

    override fun onLeftClicked(mouseX: Double, mouseY: Double)
    {
        if (isActive?.invoke() != false)
            function?.invoke()
    }
}
