package talsumi.statuesclassic.client.content.widgets

import net.minecraft.client.gui.GuiGraphics
import net.minecraft.network.chat.Component
import talsumi.statuesclassic.client.content.screen.EnhancedScreen

/**
 * A simple widget drawn as part of an [EnhancedScreen]'s background. Positions are relative to the top-left of the screen's GUI.
 */
abstract class BaseWidget(val x: Int, val y: Int, val width: Int, val height: Int) {

    /** Set by [EnhancedScreen.addWidgets]. */
    lateinit var parentScreen: EnhancedScreen<*>

    /**
     * Draws the widget. [x] and [y] are the absolute position of the GUI's top-left corner.
     */
    abstract fun doRender(graphics: GuiGraphics, x: Int, y: Int, mouseX: Int, mouseY: Int, delta: Float)

    /**
     * [x] and [y] are the absolute position of this widget's top-left corner.
     */
    open fun isHovered(x: Int, y: Int, mouseX: Int, mouseY: Int): Boolean =
        mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height

    open fun getTooltip(): List<Component>? = null

    open fun renderTooltip(screen: EnhancedScreen<*>, graphics: GuiGraphics, mouseX: Int, mouseY: Int)
    {
        val tooltip = getTooltip() ?: return
        graphics.renderComponentTooltip(screen.font(), tooltip, mouseX, mouseY)
    }

    open fun onLeftClicked(mouseX: Double, mouseY: Double) {}
    open fun onRightClicked(mouseX: Double, mouseY: Double) {}
    open fun onGeneralDragged(mouseX: Double, mouseY: Double, deltaX: Double, deltaY: Double) {}
    open fun onLeftDragged(mouseX: Double, mouseY: Double, deltaX: Double, deltaY: Double) {}
    open fun onRightDragged(mouseX: Double, mouseY: Double, deltaX: Double, deltaY: Double) {}
    open fun onReleased() {}
}
