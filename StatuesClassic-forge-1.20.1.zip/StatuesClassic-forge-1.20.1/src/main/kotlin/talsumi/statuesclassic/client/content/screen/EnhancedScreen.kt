package talsumi.statuesclassic.client.content.screen

import net.minecraft.client.gui.Font
import net.minecraft.client.gui.GuiGraphics
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
import net.minecraft.network.chat.Component
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.inventory.AbstractContainerMenu
import talsumi.statuesclassic.client.content.widgets.BaseWidget

/**
 * A container screen that draws [guiTexture] as its background and manages a list of simple [BaseWidget]s on top of it.
 */
open class EnhancedScreen<T : AbstractContainerMenu>(menu: T, inventory: Inventory, title: Component, val guiTexture: ResourceLocation) : AbstractContainerScreen<T>(menu, inventory, title) {

    val widgets = ArrayList<BaseWidget>()

    fun addWidgets(vararg newWidgets: BaseWidget)
    {
        for (widget in newWidgets) {
            widget.parentScreen = this
            widgets.add(widget)
        }
    }

    fun getScreenX(): Int = leftPos
    fun getScreenY(): Int = topPos
    fun font(): Font = font

    override fun render(graphics: GuiGraphics, mouseX: Int, mouseY: Int, partialTick: Float)
    {
        renderBackground(graphics)
        super.render(graphics, mouseX, mouseY, partialTick)
        renderTooltip(graphics, mouseX, mouseY)

        for (widget in widgets)
            if (widget.isHovered(leftPos + widget.x, topPos + widget.y, mouseX, mouseY))
                widget.renderTooltip(this, graphics, mouseX, mouseY)
    }

    override fun renderBg(graphics: GuiGraphics, partialTick: Float, mouseX: Int, mouseY: Int)
    {
        graphics.blit(guiTexture, leftPos, topPos, 0, 0, imageWidth, imageHeight)

        for (widget in widgets)
            widget.doRender(graphics, leftPos, topPos, mouseX, mouseY, partialTick)
    }

    override fun renderLabels(graphics: GuiGraphics, mouseX: Int, mouseY: Int) {}

    override fun mouseClicked(mouseX: Double, mouseY: Double, button: Int): Boolean
    {
        var handled = false
        for (widget in widgets) {
            if (widget.isHovered(leftPos + widget.x, topPos + widget.y, mouseX.toInt(), mouseY.toInt())) {
                when (button) {
                    0 -> widget.onLeftClicked(mouseX, mouseY)
                    1 -> widget.onRightClicked(mouseX, mouseY)
                }
                handled = true
            }
        }
        return if (handled) true else super.mouseClicked(mouseX, mouseY, button)
    }

    override fun mouseDragged(mouseX: Double, mouseY: Double, button: Int, dragX: Double, dragY: Double): Boolean
    {
        var dragged = false
        for (widget in widgets) {
            widget.onGeneralDragged(mouseX, mouseY, dragX, dragY)
            if (button == 0)
                widget.onLeftDragged(mouseX, mouseY, dragX, dragY)
            else
                widget.onRightDragged(mouseX, mouseY, dragX, dragY)

            dragged = true
        }
        return if (dragged) true else super.mouseDragged(mouseX, mouseY, button, dragX, dragY)
    }

    override fun mouseReleased(mouseX: Double, mouseY: Double, button: Int): Boolean
    {
        for (widget in widgets)
            widget.onReleased()

        return super.mouseReleased(mouseX, mouseY, button)
    }
}
