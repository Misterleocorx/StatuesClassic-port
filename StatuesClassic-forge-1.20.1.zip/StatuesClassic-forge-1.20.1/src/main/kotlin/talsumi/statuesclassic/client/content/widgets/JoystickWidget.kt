package talsumi.statuesclassic.client.content.widgets

import com.mojang.blaze3d.systems.RenderSystem
import com.mojang.blaze3d.vertex.BufferUploader
import com.mojang.blaze3d.vertex.DefaultVertexFormat
import com.mojang.blaze3d.vertex.Tesselator
import com.mojang.blaze3d.vertex.VertexFormat
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphics
import net.minecraft.client.renderer.GameRenderer
import net.minecraft.network.chat.Component
import talsumi.statuesclassic.client.content.screen.EnhancedScreen

class JoystickWidget(x: Int, y: Int, width: Int, height: Int, val stickSize: Int, val u: Int, val v: Int, val screen: EnhancedScreen<*>, val tooltip: Component? = null, val leftSideTooltip: Boolean = false, val callback: (() -> Unit)? = null) : BaseWidget(x, y, width, height) {

    val workingWidth = width - stickSize
    val workingHeight = height - stickSize
    var halfStickSize = stickSize / 2f
    var stickX = halfStickSize + workingWidth.toFloat() / 2
    var stickY = halfStickSize + workingHeight.toFloat() / 2

    var selected = false

    override fun doRender(graphics: GuiGraphics, x: Int, y: Int, mouseX: Int, mouseY: Int, delta: Float)
    {
        val x = this.x + x + stickX - halfStickSize
        val y = this.y + y + stickY - halfStickSize

        //Anything GuiGraphics has queued up must be drawn first so the order is kept.
        graphics.flush()

        //Render the joystick ourselves, vanilla's blit rounds to integers.
        RenderSystem.enableBlend()
        RenderSystem.setShader { GameRenderer.getPositionTexShader() }
        RenderSystem.setShaderTexture(0, parentScreen.guiTexture)
        val bufferBuilder = Tesselator.getInstance().builder
        val matrix = graphics.pose().last().pose()

        val texWidth = 256f
        val texHeight = 256f
        val xMin = x
        val xMax = x + stickSize
        val yMin = y
        val yMax = y + stickSize
        val uMin = u / texWidth
        val uMax = (u + stickSize) / texWidth
        val vMin = v / texHeight
        val vMax = (v + stickSize) / texHeight

        bufferBuilder.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX)
        bufferBuilder.vertex(matrix, xMin, yMax, 0f).uv(uMin, vMax).endVertex()
        bufferBuilder.vertex(matrix, xMax, yMax, 0f).uv(uMax, vMax).endVertex()
        bufferBuilder.vertex(matrix, xMax, yMin, 0f).uv(uMax, vMin).endVertex()
        bufferBuilder.vertex(matrix, xMin, yMin, 0f).uv(uMin, vMin).endVertex()
        BufferUploader.drawWithShader(bufferBuilder.end())
    }

    fun getXPosition(): Float = ((stickX - halfStickSize) / (workingWidth) * 2) - 1
    fun getYPosition(): Float = ((stickY - halfStickSize) / (workingHeight) * 2) - 1

    fun setPosition(x: Float, y: Float)
    {
        stickX = ((x + 1) / 2) * workingWidth + halfStickSize
        stickY = ((y + 1) / 2) * workingHeight + halfStickSize
        callback?.invoke()
    }

    override fun renderTooltip(screen: EnhancedScreen<*>, graphics: GuiGraphics, mouseX: Int, mouseY: Int)
    {
        val text = getTooltip()?.get(0) ?: return
        val font = Minecraft.getInstance().font

        val x = if (leftSideTooltip)
            screen.getScreenX() + x - font.width(text) - (width / 2)
        else
            screen.getScreenX() + x + width

        graphics.renderTooltip(font, text, x, screen.getScreenY() + y + (height / 2) + font.lineHeight)
    }

    override fun onLeftClicked(mouseX: Double, mouseY: Double)
    {
        selected = true
    }

    override fun onRightClicked(mouseX: Double, mouseY: Double)
    {
        //Reset stick to centre
        stickX = workingWidth.toFloat() / 2 + halfStickSize
        stickY = workingHeight.toFloat() / 2 + halfStickSize
        callback?.invoke()
    }

    override fun onLeftDragged(mouseX: Double, mouseY: Double, deltaX: Double, deltaY: Double)
    {
        if (selected) {
            stickX = (stickX + deltaX.toFloat()).coerceIn(halfStickSize, workingWidth + halfStickSize)
            stickY = (stickY + deltaY.toFloat()).coerceIn(halfStickSize, workingHeight + halfStickSize)
            callback?.invoke()
        }
    }

    override fun onReleased()
    {
        selected = false
    }

    override fun getTooltip(): List<Component>? = if (tooltip != null) listOf(tooltip) else null
}
