package talsumi.statuesclassic.client.content.render.entity

import com.mojang.blaze3d.vertex.PoseStack
import com.mojang.blaze3d.vertex.VertexConsumer
import com.mojang.math.Axis
import net.minecraft.client.Minecraft
import net.minecraft.client.model.EntityModel
import net.minecraft.client.model.HeadedModel
import net.minecraft.client.model.ArmedModel
import net.minecraft.client.model.PlayerModel
import net.minecraft.client.player.AbstractClientPlayer
import net.minecraft.client.renderer.MultiBufferSource
import net.minecraft.client.renderer.RenderType
import net.minecraft.client.renderer.entity.EntityRendererProvider
import net.minecraft.client.renderer.ItemInHandRenderer
import net.minecraft.client.renderer.entity.RenderLayerParent
import net.minecraft.client.renderer.entity.player.PlayerRenderer
import net.minecraft.client.renderer.entity.layers.CapeLayer
import net.minecraft.client.renderer.entity.layers.PlayerItemInHandLayer
import net.minecraft.client.renderer.entity.layers.RenderLayer
import net.minecraft.client.renderer.texture.OverlayTexture
import net.minecraft.network.chat.Component
import net.minecraft.world.entity.EquipmentSlot
import net.minecraft.world.entity.HumanoidArm
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.player.PlayerModelPart
import net.minecraft.world.item.ItemDisplayContext
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.world.level.ClipContext
import net.minecraft.world.level.block.state.properties.BlockStateProperties
import talsumi.statuesclassic.client.content.model.StatueModel
import talsumi.statuesclassic.content.blockentity.StatueBE
import talsumi.statuesclassic.core.StatueData
import talsumi.statuesclassic.core.StatueHelper
import java.awt.Color

/**
 * A [PlayerRenderer] that draws a statue's armour, held items, cape etc. using the vanilla layers.
 * It is never used to render an entity directly, only through [render].
 */
class StatuePlayerRenderer(val statueModel: StatueModel, ctx: EntityRendererProvider.Context, slim: Boolean) : PlayerRenderer(ctx, slim) {

    private val itemInHand: ItemInHandRenderer = ctx.itemInHandRenderer
    private val heldItemLayerOverride = StatueHeldItemLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>>(this, itemInHand)
    private val capeLayerOverride = StatueCapeLayer(this)

    /**
     * Getter for supplying layers with the proper context model.
     */
    override fun getModel(): PlayerModel<AbstractClientPlayer> = statueModel

    fun render(statue: StatueBE, data: StatueData, color: Color, tickDelta: Float, poseStack: PoseStack, vertex: VertexConsumer, buffer: MultiBufferSource, light: Int, overlay: Int)
    {
        //Render the statue model.
        poseStack.pushPose()

        //Rotate to match statue facing
        val facing = statue.blockState.getValue(BlockStateProperties.HORIZONTAL_FACING)
        poseStack.mulPose(Axis.YP.rotationDegrees(facing.toYRot()))

        //Apply height offset
        poseStack.translate(0.0, data.heightOffset.toDouble(), 0.0)

        //Apply master rotation
        poseStack.translate(0.0, 1.0, 0.0)
        poseStack.mulPose(Axis.YP.rotation(data.masterRotate))
        poseStack.mulPose(Axis.XP.rotation(data.masterRaise))
        poseStack.translate(0.0, -1.0, 0.0)

        statueModel.renderToBuffer(poseStack, vertex, light, overlay, color.red / 255f, color.green / 255f, color.blue / 255f, color.alpha / 255f)

        //Render features
        val player = statue.clientFakePlayer as? AbstractClientPlayer
        if (player == null) {
            poseStack.popPose()
            return
        }

        for (original in layers) {
            var layer: RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> = original

            //Ignore vanilla's held item renderer and use our own that supports rotation
            if (original is PlayerItemInHandLayer<*, *>) {
                heldItemLayerOverride.rightRotation = StatueHelper.encodeHandRotation(statue.rightHandRotate)
                heldItemLayerOverride.leftRotation = StatueHelper.encodeHandRotation(statue.leftHandRotate)
                layer = heldItemLayerOverride
            }
            //Use our own cape renderer. Like vanilla ours delegates to an AbstractClientPlayer (StatuePlayerEntity)
            else if (original is CapeLayer) {
                layer = capeLayerOverride
            }

            poseStack.pushPose()
            layer.render(poseStack, buffer, light, player, 0f, 0f, tickDelta, 0f, player.yHeadRot, player.xRot)
            poseStack.popPose()
        }

        poseStack.popPose()

        //Render nametag if applicable
        if (statue.hasName) {
            val mc = Minecraft.getInstance()

            //Raycast so we don't render when behind blocks.
            val viewer = mc.player ?: return
            val level = mc.level ?: return
            val cast = level.clip(ClipContext(
                viewer.getEyePosition(tickDelta),
                player.position().add(0.0, 2.1, 0.0),
                ClipContext.Block.VISUAL,
                ClipContext.Fluid.NONE,
                viewer))

            if (cast.blockPos == statue.blockPos.above() || cast.blockPos == statue.blockPos.above(2)) {
                poseStack.pushPose()
                poseStack.scale(1f, -1f, -1f)
                poseStack.translate(0.0, -1.4, 0.0)
                poseStack.translate(0.0, -data.heightOffset.toDouble(), 0.0)
                renderNameTag(player, Component.literal(statue.playerName ?: ""), poseStack, buffer, light)
                poseStack.popPose()
            }
        }
    }
}

class StatueHeldItemLayer<T, M>(parent: RenderLayerParent<T, M>, private val itemInHand: ItemInHandRenderer) : PlayerItemInHandLayer<T, M>(parent, itemInHand)
        where T : AbstractClientPlayer, M : EntityModel<T>, M : HeadedModel, M : ArmedModel {

    var rightRotation = 0f
    var leftRotation = 0f

    override fun renderArmWithItem(entity: LivingEntity, stack: ItemStack, displayContext: ItemDisplayContext, arm: HumanoidArm, poseStack: PoseStack, buffer: MultiBufferSource, light: Int)
    {
        if (!stack.isEmpty) {
            poseStack.pushPose()
            parentModel.translateToHand(arm, poseStack)
            poseStack.mulPose(Axis.XP.rotationDegrees(-90.0f))
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0f))
            val left = arm == HumanoidArm.LEFT
            poseStack.translate(((if (left) -1 else 1).toFloat() / 16.0f).toDouble(), 0.0, 0.0) //Centre on arm
            poseStack.translate(0.0, 0.0, -0.5) //Move down arm
            poseStack.mulPose(Axis.XP.rotation(if (arm == HumanoidArm.RIGHT) rightRotation else leftRotation)) //Rotate item
            poseStack.translate(0.0, 0.125, -0.125) //Centre item on rotation
            itemInHand.renderItem(entity, stack, displayContext, left, poseStack, buffer, light)
            poseStack.popPose()
        }
    }
}

class StatueCapeLayer(parent: RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>>) : CapeLayer(parent) {

    override fun render(poseStack: PoseStack, buffer: MultiBufferSource, light: Int, player: AbstractClientPlayer, limbSwing: Float, limbSwingAmount: Float, partialTick: Float, ageInTicks: Float, netHeadYaw: Float, headPitch: Float)
    {
        val cape = player.cloakTextureLocation
        if (player.isCapeLoaded && player.isModelPartShown(PlayerModelPart.CAPE) && cape != null && !player.getItemBySlot(EquipmentSlot.CHEST).`is`(Items.ELYTRA)) {

            poseStack.pushPose()
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0f))
            poseStack.translate(0.0, 0.0, -0.16)
            poseStack.mulPose(Axis.XP.rotationDegrees(-8.0f))
            val vertices: VertexConsumer = buffer.getBuffer(RenderType.entitySolid(cape))
            parentModel.renderCloak(poseStack, vertices, light, OverlayTexture.NO_OVERLAY)
            poseStack.popPose()
        }
    }
}
