package talsumi.statuesclassic.client.content.screen

import com.mojang.authlib.GameProfile
import com.mojang.blaze3d.platform.Lighting
import com.mojang.blaze3d.systems.RenderSystem
import com.mojang.blaze3d.vertex.PoseStack
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphics
import net.minecraft.client.gui.components.EditBox
import net.minecraft.client.renderer.texture.OverlayTexture
import net.minecraft.client.resources.DefaultPlayerSkin
import net.minecraft.network.chat.Component
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.state.BlockState
import talsumi.statuesclassic.StatuesClassic
import talsumi.statuesclassic.client.content.render.blockentity.StatueBERenderer
import talsumi.statuesclassic.client.content.widgets.ButtonWidget
import talsumi.statuesclassic.client.content.widgets.JoystickWidget
import talsumi.statuesclassic.client.core.SkinHandler
import talsumi.statuesclassic.content.menu.StatueCreationMenu
import talsumi.statuesclassic.core.StatueData
import talsumi.statuesclassic.core.StatueHelper
import talsumi.statuesclassic.networking.ClientPacketsOut
import java.util.*

class StatueCreationScreen(menu: StatueCreationMenu, inventory: Inventory, title: Component) :
    EnhancedScreen<StatueCreationMenu>(menu, inventory, title, ResourceLocation(StatuesClassic.MODID, "textures/gui/statue_creation_overlay.png")) {

    private val underlayTexture = ResourceLocation(StatuesClassic.MODID, "textures/gui/statue_creation_underlay.png")
    private val joystick1: JoystickWidget
    private val joystick2: JoystickWidget
    private val joystick3: JoystickWidget
    private val joystick4: JoystickWidget
    private val joystick5: JoystickWidget
    private val joystick6: JoystickWidget
    private lateinit var nameField: EditBox
    /**
     * The name that was stored in [nameField] the previous tick.
     */
    private var lastName: String = ""
    /**
     * The UUID sent by the server that matches the name queried.
     */
    private var uuid: UUID? = null
    /**
     * The actual name (case-sensitive) of the shown player.
     */
    private var trueName: String? = null
    private var lookupDelay = 0
    private var data = StatueData(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)
    private var block: BlockState

    private val renderer = StatueBERenderer()

    private val fullbright = 0xF000F0

    init
    {
        imageWidth = 198
        imageHeight = 208
        joystick1 = JoystickWidget(145, 7, 48, 48, 14, 198, 0, this,
            Component.translatable("gui.statuesclassic.joystick.creation_left_arm"), callback = ::joystickChange)
        joystick2 = JoystickWidget(5, 7, 48, 48, 14, 198, 0, this,
            Component.translatable("gui.statuesclassic.joystick.creation_right_arm"), true, callback = ::joystickChange)
        joystick3 = JoystickWidget(145, 59, 48, 48, 14, 198, 0, this,
            Component.translatable("gui.statuesclassic.joystick.creation_left_leg"), callback = ::joystickChange)
        joystick4 = JoystickWidget(5, 59, 48, 48, 14, 198, 0, this,
            Component.translatable("gui.statuesclassic.joystick.creation_right_leg"), true, callback = ::joystickChange)
        joystick5 = JoystickWidget(5, 111, 48, 48, 14, 198, 0, this,
            Component.translatable("gui.statuesclassic.joystick.creation_head"), true, callback = ::joystickChange)
        joystick6 = JoystickWidget(145, 111, 48, 48, 14, 198, 0, this,
            Component.translatable("gui.statuesclassic.joystick.creation_body"), callback = ::joystickChange)
        val randomizeButton = ButtonWidget(4, 162, 190, 20, 0, 208, ::randomize, { Component.translatable("gui.statuesclassic.randomize") })
        val formButton = object : ButtonWidget(4, 184, 190, 20, 0, 208, ::form, { Component.translatable("gui.statuesclassic.sculpt") }, { uuid != null }) {
            override fun getTooltip(): List<Component>?
            {
                return if (uuid == null) listOf(Component.translatable("gui.statuesclassic.sculpt_invalid")) else null
            }
        }

        addWidgets(joystick1, joystick2, joystick3, joystick4, joystick5, joystick6, randomizeButton, formButton)

        block = Minecraft.getInstance().level?.getBlockState(menu.parentPos) ?: Blocks.STONE.defaultBlockState()
    }

    override fun init()
    {
        super.init()
        nameField = EditBox(font, leftPos + 59, topPos + 139, 80, 12, Component.translatable("gui.statuesclassic.player_name_field"))
        nameField.setEditable(true)
        nameField.setTextColor(-1)
        nameField.setTextColorUneditable(-1)
        nameField.setBordered(false)
        addWidget(nameField)
        setInitialFocus(nameField)
    }

    private fun joystickChange()
    {
        StatueHelper.applyJoystickAnglesToStatueData(data,
            joystick1.getYPosition(),
            joystick1.getXPosition(),
            joystick2.getYPosition(),
            joystick2.getXPosition(),
            joystick3.getYPosition(),
            joystick3.getXPosition(),
            joystick4.getYPosition(),
            joystick4.getXPosition(),
            joystick5.getYPosition(),
            joystick5.getXPosition(),
            joystick6.getYPosition(),
            joystick6.getXPosition())
    }

    fun form()
    {
        if (uuid == null || trueName == null)
            return

        ClientPacketsOut.sendFormStatuePacket(trueName!!, uuid!!, data)
    }

    fun randomize()
    {
        for (widget in widgets)
            if (widget is JoystickWidget)
                widget.setPosition(Math.random().toFloat() * 2f - 1f, Math.random().toFloat() * 2f - 1f)
    }

    fun receiveProfile(queriedName: String, profile: GameProfile?)
    {
        if (queriedName.lowercase() == lastName.lowercase()) {
            if (profile != null) {
                uuid = profile.id
                trueName = profile.name
            }
        }
        else {
            //If name has changed while the lookup was processing, schedule another lookup
            lookupDelay = 0
        }
    }

    override fun containerTick()
    {
        super.containerTick()
        nameField.tick()

        //Check if the input name has changed.
        if ((nameField.value.isNotEmpty() && nameField.value != lastName)) {
            //Schedule a lookup request
            if (lookupDelay == -1)
                lookupDelay = 0

            //Invalidate uuid and skin
            invalidateInfo()

            lastName = nameField.value
            if (lastName.isEmpty())
                invalidateInfo()
        }

        if (lookupDelay > -1) {
            lookupDelay++

            //Make sure not to spam lookup requests. The server-enforced limit is 1 per second, per player.
            if (lookupDelay >= 25) {
                lookupDelay = -1
                //This will eventually update the uuid and username in this screen.
                ClientPacketsOut.sendLookupUuidPacket(lastName)
            }
        }
    }

    private fun invalidateInfo()
    {
        uuid = null
        trueName = null
    }

    override fun render(graphics: GuiGraphics, mouseX: Int, mouseY: Int, partialTick: Float)
    {
        super.render(graphics, mouseX, mouseY, partialTick)
        nameField.render(graphics, mouseX, mouseY, partialTick)
    }

    override fun renderBg(graphics: GuiGraphics, partialTick: Float, mouseX: Int, mouseY: Int)
    {
        //Render underlay
        graphics.blit(underlayTexture, leftPos, topPos, 0, 0, imageWidth, imageHeight)

        //Render player model
        val middleX = leftPos + imageWidth / 2.0
        val middleY = topPos + imageHeight / 2.0
        drawModel(graphics, 45f, middleX, middleY - 65.0, partialTick)

        //Render ui
        super.renderBg(graphics, partialTick, mouseX, mouseY)
    }

    private fun drawModel(graphics: GuiGraphics, size: Float, x: Double, y: Double, delta: Float)
    {
        //Mirrors InventoryScreen#renderEntityInInventory
        val skinData = if (uuid != null) SkinHandler.getCachedSkin(uuid!!) else null
        val skin = skinData?.getSkinOrDefault() ?: DefaultPlayerSkin.getDefaultSkin()

        //Make sure everything queued so far is drawn before we change the view matrix.
        graphics.flush()

        val viewStack = RenderSystem.getModelViewStack()
        viewStack.pushPose()
        viewStack.translate(x, y, 1050.0)
        viewStack.scale(1.0f, 1.0f, -1.0f)
        RenderSystem.applyModelViewMatrix()

        val ourMatrix = PoseStack()
        ourMatrix.translate(0.0, 0.0, 1000.0)
        ourMatrix.scale(size, -size, -size)

        Lighting.setupForEntityInInventory()

        val buffer = Minecraft.getInstance().renderBuffers().bufferSource()
        RenderSystem.runAsFancy {
            renderer.render(null, data, block, uuid, skinData?.slim ?: false, skin, delta, ourMatrix, buffer, fullbright, OverlayTexture.NO_OVERLAY)
        }
        buffer.endBatch()

        viewStack.popPose()
        RenderSystem.applyModelViewMatrix()
        Lighting.setupFor3DItems()
    }

    override fun keyPressed(keyCode: Int, scanCode: Int, modifiers: Int): Boolean
    {
        if (keyCode == 256)
            minecraft!!.player!!.closeContainer()
        return if (!nameField.keyPressed(keyCode, scanCode, modifiers) && !nameField.canConsumeInput()) super.keyPressed(keyCode, scanCode, modifiers) else true
    }
}
