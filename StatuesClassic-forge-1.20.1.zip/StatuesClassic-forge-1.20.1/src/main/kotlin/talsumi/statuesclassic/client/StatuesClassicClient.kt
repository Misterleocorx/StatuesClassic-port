package talsumi.statuesclassic.client

import net.minecraft.client.gui.screens.MenuScreens
import net.minecraftforge.client.event.EntityRenderersEvent
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent
import talsumi.statuesclassic.client.content.render.blockentity.StatueBERenderer
import talsumi.statuesclassic.client.content.screen.StatueCreationScreen
import talsumi.statuesclassic.client.content.screen.StatueEquipmentScreen
import talsumi.statuesclassic.client.core.SkinHandler
import talsumi.statuesclassic.content.ModBlockEntities
import talsumi.statuesclassic.content.ModMenus
import talsumi.statuesclassic.content.menu.StatueCreationMenu
import talsumi.statuesclassic.content.menu.StatueEquipmentMenu
import thedarkcolour.kotlinforforge.forge.MOD_BUS

object StatuesClassicClient {

    fun init()
    {
        MOD_BUS.addListener<FMLClientSetupEvent> { event ->
            event.enqueueWork {
                MenuScreens.register(ModMenus.STATUE_EQUIPMENT.get(),
                    MenuScreens.ScreenConstructor<StatueEquipmentMenu, StatueEquipmentScreen> { menu, inv, title -> StatueEquipmentScreen(menu, inv, title) })
                MenuScreens.register(ModMenus.STATUE_CREATION.get(),
                    MenuScreens.ScreenConstructor<StatueCreationMenu, StatueCreationScreen> { menu, inv, title -> StatueCreationScreen(menu, inv, title) })
            }
        }

        MOD_BUS.addListener<EntityRenderersEvent.RegisterRenderers> { event ->
            event.registerBlockEntityRenderer(ModBlockEntities.STATUE.get()) { StatueBERenderer() }
        }

        MOD_BUS.addListener<RegisterClientReloadListenersEvent> { event ->
            event.registerReloadListener(SkinHandler.ReloadListener)
        }
    }
}
