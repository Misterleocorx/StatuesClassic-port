package talsumi.statuesclassic.client

import net.minecraft.client.Minecraft
import net.minecraft.core.BlockPos
import talsumi.statuesclassic.content.blockentity.StatueBE

/**
 * Client-only lookups, kept out of common classes so they never get loaded on a dedicated server.
 */
object ClientAccess {

    fun getStatue(pos: BlockPos): StatueBE? = Minecraft.getInstance().level?.getBlockEntity(pos) as? StatueBE
}
