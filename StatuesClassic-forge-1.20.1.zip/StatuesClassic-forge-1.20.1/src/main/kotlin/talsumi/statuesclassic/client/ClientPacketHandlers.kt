package talsumi.statuesclassic.client

import net.minecraft.client.Minecraft
import talsumi.statuesclassic.client.content.screen.StatueCreationScreen
import talsumi.statuesclassic.client.content.screen.StatueEquipmentScreen
import talsumi.statuesclassic.networking.StatueGuiHandsPacket
import talsumi.statuesclassic.networking.StatueProfilePacket

/**
 * Handlers for packets sent by the server. Called on the client thread.
 */
object ClientPacketHandlers {

    fun receiveStatueProfile(packet: StatueProfilePacket)
    {
        val screen = Minecraft.getInstance().screen

        if (screen is StatueCreationScreen)
            screen.receiveProfile(packet.queriedName, packet.profile)
    }

    fun receiveStatueHands(packet: StatueGuiHandsPacket)
    {
        val screen = Minecraft.getInstance().screen

        if (screen is StatueEquipmentScreen)
            screen.joysticksUpdatedFromServer(packet.left, packet.right)
    }
}
